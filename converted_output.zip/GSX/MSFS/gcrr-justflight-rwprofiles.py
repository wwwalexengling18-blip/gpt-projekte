# -- coding: utf-8 --

msfs_mode = 1
icao = "gcrr"

@AlternativeStopPositions
def customOffsetStands1line(aircraftData):

	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandsTerminal1Gate1(aircraftData):

	table = {
		0: 0,
		737: 1.51,
		82: 5.22,
		83: 5.22,
		88: 5.22,
		757: 6.71,
		340: 8.36,
		767: 8.36,
		330: 8.36,
		777: 8.36,
		787: 8.36,
		747: 13.43,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandsTerminal1Gate2(aircraftData):

	table = {
		0: 0,
		737: 1.59,
		82: 3.88,
		83: 3.88,
		88: 3.88,
		757: 6.71,
		340: 9.22,
		767: 9.22,
		330: 9.22,
		777: 9.22,
		787: 9.22,
		747: 9.22,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandsTerminal1Gate3(aircraftData):

	table = {
		0: 0,
		737: 1.51,
		82: 3.89,
		83: 3.89,
		88: 3.89,
		757: 6.7,
		340: 8.22,
		767: 8.22,
		330: 8.22,
		777: 8.22,
		787: 8.22,
		747: 8.22,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandsTerminal1Gate4(aircraftData):

	table = {
		0: 0,
		82: 2.08,
		83: 2.08,
		88: 2.08,
		757: 3.94,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandsTerminal1Gate5(aircraftData):

	table = {
		0: 0,
		737: 1.6,
		82: 3.92,
		83: 3.92,
		88: 3.92,
		757: 6.73,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandsTerminal1Gate6(aircraftData):

	table = {
		0: 0,
		737: 1.55,
		757: 6.78,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetRemoteStandsGate1112(aircraftData):

	table = {
		0: 0,
		757: 2.1,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetRemoteStandsGate1314(aircraftData):

	table = {
		0: 0,
		757: 2.2,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

def MyStandNames(name, letter, priority):
	return CustomizedName( "%s|Stand %s#§" % (name, letter), priority )

Terminal1Names = MyStandNames("Terminal 1 (All Airlines)", "T", 1)
Terminal2Names = MyStandNames("Terminal 2 (Binter)", "", 2)
RemoteNames = MyStandNames("Remote Parking", "", 3)
GANames = MyStandNames("General Aviation Parking", "AG", 4)
MilitaryNames = MyStandNames("Military Apron", "", 5)

parkings = {
	GATE_T : {
		None : ( ),
		1 : (Terminal1Names, customOffsetStandsTerminal1Gate1),
		2 : (Terminal1Names, customOffsetStandsTerminal1Gate2),
		3 : (Terminal1Names, customOffsetStandsTerminal1Gate3),
		4 : (Terminal1Names, customOffsetStandsTerminal1Gate4),
		5 : (Terminal1Names, customOffsetStandsTerminal1Gate5),
		6 : (Terminal1Names, customOffsetStandsTerminal1Gate6),
	},
	PARKING : {
		None : ( ),
		1 : (GANames, ),
		2 : (GANames, ),
		3 : (GANames, ),
		4 : (GANames, ),
		7 : (Terminal2Names, customOffsetStands1line),
		8 : (Terminal2Names, customOffsetStands1line),
		10 : (Terminal2Names, customOffsetStands1line),
		11 : (RemoteNames, customOffsetRemoteStandsGate1112),
		12 : (RemoteNames, customOffsetRemoteStandsGate1112),
		13 : (RemoteNames, customOffsetRemoteStandsGate1314),
		14 : (RemoteNames, customOffsetRemoteStandsGate1314),
		15 : (RemoteNames, customOffsetStands1line),
		16 : (RemoteNames, customOffsetStands1line),
		17 : (RemoteNames, customOffsetStands1line),
		18 : (RemoteNames, customOffsetStands1line),
		19 : (RemoteNames, customOffsetStands1line),
		20 : (RemoteNames, customOffsetStands1line),
		21 : (RemoteNames, customOffsetStands1line),
		22 : (RemoteNames, customOffsetStands1line),
		23 : (RemoteNames, customOffsetStands1line),
		24 : (RemoteNames, customOffsetStands1line),
	},
	0 : {
		None : ( ),
		2 : (MilitaryNames, ),
	},
	S_PARKING : {
		None : ( ),
		1 : (MilitaryNames, ),
	},
}