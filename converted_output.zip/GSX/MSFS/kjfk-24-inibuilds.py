# -- coding: utf-8 --

msfs_mode = 1
icao = "kjfk"

def HandleAircraftOffsets(aircraftData, specificTables, genericTable):
	major_id = aircraftData.idMajor
	minor_id = aircraftData.idMinor

	if major_id in specificTables:
		specific_table, fallback_key = specificTables[major_id]
		result = specific_table.get(minor_id)
		if result is None:
			result = specific_table.get(fallback_key)
	else:
		result = genericTable.get(major_id, 0)

	return result

@AlternativeStopPositions
def customOffsetStands1line(aircraftData):

	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal1Gate1(aircraftData):

	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.5,
		321: 3.5,
		320: 3.5,
		777: 8.05,
		330: 8.05,
		350: 8.05,
		747: 12.05,
		767: 12.05,
		340: 12.05,
	}

	table787 = {
		0: 8.05,
		8: 8.05,
		9: 12.05,
		10: 12.05,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate2(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.85,
		321: 3.85,
		320: 3.85,
		777: 8.05,
		330: 8.05,
		350: 8.05,
		747: 12.05,
		767: 12.05,
		340: 12.05,
	}

	table787 = {
		0: 8.05,
		8: 8.05,
		9: 12.05,
		10: 12.05,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate3(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.55,
		321: 3.55,
		320: 3.55,
		777: 8.15,
		330: 8.15,
		350: 8.15,
		747: 12,
		767: 12,
		340: 12,
	}

	table787 = {
		0: 8.15,
		8: 8.015,
		9: 12,
		10: 12,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate4(aircraftData):
	table = {
		0: 8.2,
		737: 0,
		195: 0,
		900: 0,
		757: 3.2,
		321: 3.2,
		320: 3.2,
		777: 8.2,
		330: 8.2,
		350: 8.2,
		747: 12.2,
		767: 12.2,
		340: 12.2,
	}

	table787 = {
		0: 8.2,
		8: 8.2,
		9: 12.2,
		10: 12.2,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate5(aircraftData):
	table = {
		0: 8.15,
		737: 0,
		195: 0,
		900: 0,
		757: 3.6,
		321: 3.6,
		320: 3.6,
		777: 8.15,
		330: 8.15,
		350: 8.15,
		380: 8.15,
		747: 12.15,
		767: 12.15,
		340: 12.15,
	}

	table787 = {
		0: 8.15,
		8: 8.15,
		9: 12.15,
		10: 12.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate6(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.55,
		321: 3.55,
		320: 3.55,
		777: 8,
		330: 8,
		350: 8,
		747: 12.1,
		767: 12.1,
		340: 12.1,
	}

	table787 = {
		0: 8,
		8: 8,
		9: 12.1,
		10: 12.1,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate7(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.65,
		321: 3.65,
		320: 3.65,
		777: 8.15,
		330: 8.15,
		350: 8.15,
		380: 8.15,
		747: 12.15,
		767: 12.15,
		340: 12.15,
	}

	table787 = {
		0: 8.15,
		8: 8.15,
		9: 12.15,
		10: 12.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate8(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.65,
		321: 3.65,
		320: 3.65,
		777: 8.1,
		330: 8.1,
		350: 8.1,
		380: 8.1,
		747: 12.15,
		767: 12.15,
		340: 12.15,
	}

	table787 = {
		0: 8.1,
		8: 8.1,
		9: 12.15,
		10: 12.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate9(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 3.65,
		321: 3.65,
		320: 3.65,
		777: 8,
		330: 8,
		350: 8,
		747: 12.1,
		767: 12.1,
		340: 12.1,
	}

	table787 = {
		0: 8,
		8: 8,
		9: 12.1,
		10: 12.1,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal1Gate10(aircraftData):
	table = {
		0: 8.05,
		737: 0,
		195: 0,
		900: 0,
		757: 5,
		321: 5,
		320: 5,
		777: 9.45,
		330: 9.45,
		350: 9.45,
		747: 13.35,
		767: 13.35,
		340: 13.35,
	}

	table787 = {
		0: 9.45,
		8: 9.45,
		9: 13.35,
		10: 13.35,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {787 : (table787, 10)}, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate2(aircraftData):
	table = {
		0: 0,
		737: 0,
		195: 0,
		900: 0,
		320: 0,
		757: 4.25,
		321: 4.25,
		787: 5.9,
		330: 9.1,
		350: 9.1,
		747: 9.1,
		767: 9.1,
		340: 9.1,
		380: 12.4,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate3(aircraftData):
	table = {
		0: 0,
		737: 0,
		195: 0,
		900: 0,
		320: 0,
		757: 4.45,
		321: 4.45,
		787: 7.55,
		330: 9,
		350: 9,
		747: 9,
		767: 9,
		340: 9,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate4(aircraftData):
	table = {
		0: 0,
		737: 0,
		195: 0,
		900: 0,
		320: 0,
		757: 6.25,
		321: 6.25,
		787: 6.25,
		330: 12.25,
		350: 12.25,
		767: 12.25,
		340: 12.25,
		747: 13.85,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate5(aircraftData):
	table = {
		0: 0,
		737: 0,
		195: 0,
		900: 0,
		320: 0,
		757: 0,
		321: 0,
		787: 3.05,
		330: 7.6,
		350: 7.6,
		767: 7.6,
		340: 7.6,
		747: 7.6,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate6(aircraftData):
	table = {
		0: 0,
		737: 0,
		195: 0,
		900: 0,
		320: 0,
		321: 0,
		757: 3.9,
		787: 8.6,
		330: 8.6,
		350: 8.6,
		767: 8.6,
		340: 11.15,
		747: 11.15,
		380: 15,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate8(aircraftData):
	table = {
		0: 0,
		737: 0,
		195: 0,
		320: 0,
		321: 0,
		900: 15.15,
		700: 15.15,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate9(aircraftData):
	table = {
		0: 0,
		737: 0,
		170: 0,
		175: 0,
		190: 0,
		195: 0,
		320: 0,
		321: 8.5,
		900: 8.5,
		700: 8.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate101112(aircraftData):
	table = {
		0: 0,
		737: 8.6,
		170: 8.6,
		175: 8.6,
		190: 8.6,
		195: 8.6,
		320: 8.6,
		321: 8.6,
		900: 8.6,
		700: 8.6,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate14(aircraftData):
	table = {
		0: 0,
		737: 6.95,
		170: 6.95,
		175: 6.95,
		190: 6.95,
		195: 6.95,
		320: 6.95,
		321: 6.95,
		900: 6.95,
		700: 6.95,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate15(aircraftData):
	table = {
		0: 0,
		737: 3.55,
		170: 3.55,
		175: 3.55,
		190: 3.55,
		195: 3.55,
		320: 3.55,
		321: 3.55,
		900: 3.55,
		700: 3.55,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate16(aircraftData):
	table = {
		0: 0,
		737: 4.55,
		170: 4.55,
		175: 4.55,
		190: 4.55,
		195: 4.55,
		320: 4.55,
		321: 4.55,
		900: 4.55,
		700: 4.55,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate17(aircraftData):
	table = {
		0: 0,
		737: 8,
		170: 8,
		175: 8,
		190: 8,
		195: 8,
		320: 8,
		321: 8,
		900: 8,
		700: 8,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate19(aircraftData):
	table = {
		0: 0,
		737: 7.95,
		170: 7.95,
		175: 7.95,
		190: 7.95,
		195: 7.95,
		320: 7.95,
		321: 7.95,
		900: 7.95,
		700: 7.95,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate21(aircraftData):
	table = {
		0: 0,
		737: 7.2,
		170: 7.2,
		175: 7.2,
		190: 7.2,
		195: 7.2,
		320: 7.2,
		321: 7.2,
		900: 7.2,
		700: 7.2,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate22(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 5.55,
		350: 19.2,
	}

	table767 = {
		0: 2.8,
		300: 2.8,
		400: 13.8,
	}

	table777 = {
		0: 5.55,
		200: 5.55,
		300: 13.8,
	}

	table787 = {
		0: 5.55,
		8: 5.55,
		9: 9.65,
		10: 9.65,
	}

	table330 = {
		0: 2.8,
		200: 2.8,
		300: 9.65,
		800: 2.8,
		900: 9.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData,
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate26(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 5.5,
		350: 19.2,
	}

	table767 = {
		0: 2.75,
		300: 2.75,
		400: 15.1,
	}

	table777 = {
		0: 5.5,
		200: 5.5,
		300: 15.1,
	}

	table787 = {
		0: 5.5,
		8: 5.5,
		9: 10.95,
		10: 10.95,
	}

	table330 = {
		0: 2.75,
		200: 2.75,
		300: 10.95,
		800: 2.75,
		900: 10.95,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData,
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate27(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 9.6,
		350: 19.2,
	}

	table767 = {
		0: 5.3,
		300: 5.3,
		400: 16.45,
	}

	table777 = {
		0: 9.6,
		200: 9.6,
		300: 16.45,
	}

	table787 = {
		0: 9.6,
		8: 9.6,
		9: 12.35,
		10: 12.35,
	}

	table330 = {
		0: 5.3,
		200: 5.3,
		300: 12.35,
		800: 5.3,
		900: 12.35,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets(aircraftData,
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate28(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 5.5,
		350: 19.2,
	}

	table767 = {
		0: 2.75,
		300: 2.75,
		400: 15.1,
	}

	table777 = {
		0: 5.5,
		200: 5.5,
		300: 15.1,
	}

	table787 = {
		0: 5.5,
		8: 5.5,
		9: 10.95,
		10: 10.95,
	}

	table330 = {
		0: 2.75,
		200: 2.75,
		300: 10.95,
		800: 2.75,
		900: 10.95,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate29(aircraftData):
	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate30(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.8,
		350: 16.35,
	}

	table767 = {
		0: 4,
		300: 4,
		400: 13.6,
	}

	table777 = {
		0: 6.8,
		200: 6.8,
		300: 13.6,
	}

	table787 = {
		0: 6.8,
		8: 6.8,
		9: 10.9,
		10: 10.9,
	}

	table330 = {
		0: 4,
		200: 4,
		300: 10.9,
		800: 4,
		900: 10.9,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate31(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.85,
		350: 15.1,
	}

	table767 = {
		0: 4.15,
		300: 4.15,
		400: 12.3,
	}

	table777 = {
		0: 6.85,
		200: 6.85,
		300: 12.3,
	}

	table787 = {
		0: 6.85,
		8: 6.85,
		9: 9.55,
		10: 9.55,
	}

	table330 = {
		0: 4.15,
		200: 4.15,
		300: 9.55,
		800: 4.15,
		900: 9.55,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate32(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.75,
		350: 16.25,
	}

	table767 = {
		0: 4,
		300: 4,
		400: 13.15,
	}

	table777 = {
		0: 6.75,
		200: 6.75,
		300: 13.15,
	}

	table787 = {
		0: 6.75,
		8: 6.75,
		9: 10.85,
		10: 10.85,
	}

	table330 = {
		0: 4,
		200: 4,
		300: 10.85,
		800: 4,
		900: 10.85,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate33(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 8.1,
		80: 10.8,
	}

	table767 = {
		0: 13.5,
		300: 13.5,
		400: 16.25,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, { 767 : (table767, 0), }, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate34(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.7,
		350: 14.85,
	}

	table767 = {
		0: 3.95,
		300: 3.95,
		400: 12.2,
	}

	table777 = {
		0: 6.7,
		200: 6.7,
		300: 12.2,
	}

	table787 = {
		0: 6.7,
		8: 6.7,
		9: 9.45,
		10: 9.45,
	}

	table330 = {
		0: 3.95,
		200: 3.95,
		300: 9.45,
		800: 3.95,
		900: 9.45,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate35(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 4.15,
		80: 10.8,
	}

	table767 = {
		0: 8.15,
		300: 8.15,
		400: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, { 767 : (table767, 0), }, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate36(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.7,
		80: 9.45,
	}

	table767 = {
		0: 12.2,
		300: 12.2,
		400: 14.9,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, { 767 : (table767, 0), }, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate37(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.8,
		350: 16.25,
	}

	table767 = {
		0: 4,
		300: 4,
		400: 13.5,
	}

	table777 = {
		0: 6.8,
		200: 6.8,
		300: 13.5,
	}

	table787 = {
		0: 6.8,
		8: 6.8,
		9: 9.5,
		10: 9.5,
	}

	table330 = {
		0: 4,
		200: 4,
		300: 9.5,
		800: 4,
		900: 9.5,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate38(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.75,
		350: 16.3,
	}

	table767 = {
		0: 4,
		300: 4,
		400: 13.65,
	}

	table777 = {
		0: 6.75,
		200: 6.75,
		300: 13.65,
	}

	table787 = {
		0: 6.75,
		8: 6.75,
		9: 10.85,
		10: 10.85,
	}

	table330 = {
		0: 4,
		200: 4,
		300: 10.85,
		800: 4,
		900: 10.85,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate39(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.8,
		350: 14.95,
	}

	table767 = {
		0: 4.05,
		300: 4.05,
		400: 12.2,
	}

	table777 = {
		0: 6.8,
		200: 6.8,
		300: 12.2,
	}

	table787 = {
		0: 6.8,
		8: 6.8,
		9: 9.5,
		10: 9.5,
	}

	table330 = {
		0: 4.05,
		200: 4.05,
		300: 9.5,
		800: 4.05,
		900: 9.5,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate41(aircraftData):
	table = {
		0: 0,
		737: 0,
		221: 0,
		223: 0,
		319: 0,
		320: 0,
		321: 0,
		757: 6.8,
		350: 16.25,
	}

	table767 = {
		0: 4,
		300: 4,
		400: 12.2,
	}

	table777 = {
		0: 6.8,
		200: 6.8,
		300: 12.2,
	}

	table787 = {
		0: 6.8,
		8: 6.8,
		9: 9.5,
		10: 9.5,
	}

	table330 = {
		0: 4,
		200: 4,
		300: 9.5,
		800: 4,
		900: 9.5,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			767 : (table767, 0),
			787 : (table787, 10),
			777 : (table777, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate42444653(aircraftData):
	table = {
		0: 0,
		200: 0,
		700: 0,
		145: 0,
		900: 2.8,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate434547(aircraftData):
	table = {
		0: 0,
		200: 0,
		700: 0,
		145: 0,
		900: 3,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate48(aircraftData):
	table = {
		0: 0,
		200: 0,
		700: 0,
		145: 0,
		900: 3.35,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate49(aircraftData):
	table = {
		0: 0,
		200: 0,
		700: 0,
		145: 0,
		900: 3.05,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate51(aircraftData):
	table = {
		0: 0,
		200: 0,
		700: 0,
		145: 0,
		900: 2.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal4Gate55(aircraftData):
	table = {
		0: 0,
		200: 0,
		700: 0,
		145: 0,
		900: 3.55,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal5Gate1(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.51,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate2(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.52,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate345791012(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.91,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate6(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.9,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate16(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 2.95,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate81421(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.83,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate11(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		321: 0,
		737: 0,
		330: 4.37,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate15(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.83,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTerminal5Gate17181920(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.8,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal5Gate222324252627282930(aircraftData):
	table = {
		0: 0,
		221: 0,
		223: 0,
		320: 0,
		190: 0,
		321: 3.7,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate1(aircraftData):
	table = {
		0: 0,
		318: 0,
		319: 0,
		320: 0,
		321: 4.2,
	}

	table757 = {
		0: 6.05,
		200: 6.05,
		300: 10.4,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, { 757 : (table757, 0), }, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate2(aircraftData):
	table = {
		0: 0,
		318: 0,
		319: 0,
		320: 0,
		321: 4.75,
		757: 12.3,
	}

	table767 = {
		0: 12.3,
		200: 12.3,
		300: 19.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, { 767 : (table767, 0), }, table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate3(aircraftData):
	table = {
		0: 0,
		737: 0,
		787: 14.2,
		350: 14.2,
		777: 14.2,
		340: 19.45,
		747: 22.2,
	}

	table757 = {
		0: 5.15,
		200: 5.15,
		300: 14.2,
	}


	table767 = {
		0: 5.15,
		300: 5.15,
		400: 19.45,
	}

	table330 = {
		0: 8.8,
		200: 8.8,
		300: 14.2,
		800: 8.8,
		900: 14.2,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
			767 : (table767, 0),
			330 : (table330, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate4(aircraftData):
	table = {
		0: 0,
		737: 0,
		170: 0,
		318: 2.9,
		319: 2.9,
		320: 2.9,
		321: 2.9,
		767: 2.9,
		747: 6.2,
		757: 9.9,
		777: 18.15,
	}

	table330 = {
		0: 6.2,
		200: 14.55,
		300: 6.2,
	}

	table340 = {
		0: 6.2,
		200: 6.2,
		300: 9.9,
		500: 14.55,
		600: 18.15,
	}

	table350 = {
		0: 6.2,
		800: 6.2,
		900: 14.55,
		1000: 21.45,
	}

	table787 = {
		0: 6.2,
		8: 6.2,
		9: 14.55,
		10: 18.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
			787 : (table787, 10),
		},
		table) - 0.25 )


@AlternativeStopPositions
def customOffsetTerminal7Gate5(aircraftData):
	table = {
		0: 0,
		737: 0,
		170: 0,
		318: 0,
		319: 0,
		320: 0,
		321: 0,
		747: 6.1,
		340: 6.1,
		757: 6.1,
	}

	table350 = {
		0: 6.1,
		800: 6.1,
		900: 6.1,
		1000: 11.95,
	}

	table787 = {
		0: 6.1,
		8: 6.1,
		9: 11.95,
		10: 11.95,
	}

	table777 = {
		0: 0,
		200: 0,
		300: 11.95,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			350 : (table350, 0),
			777 : (table777, 0),
			787 : (table787, 10),
		},
		table) - 0.25 )


@AlternativeStopPositions
def customOffsetTerminal7Gate6(aircraftData):
	table = {
		0: 0,
		170: 0,
		318: 12.55,
		319: 12.55,
		320: 12.55,
		321: 12.55,
		737: 18.75,
		757: 18.75,
		767: 2.65,
		330: 5.9,
	}

	table340 = {
		0: 5.9,
		200: 5.9,
		300: 5.9,
		500: 5.9,
		600: 18.75,
	}

	table350 = {
		0: 10.4,
		800: 10.4,
		900: 10.4,
		1000: 18.75,
	}

	table747 = {
		0: 15.6,
		400: 10.4,
		8: 15.6,
		800: 15.6,
	}

	table777 = {
		0: 10.4,
		200: 10.4,
		300: 18.75,
	}

	table787 = {
		0: 10.4,
		8: 10.4,
		9: 15.6,
		10: 15.6,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			340 : (table340, 0),
			350 : (table350, 0),
			747 : (table747, 0),
			777 : (table777, 10),
			787 : (table787, 10),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate7(aircraftData):
	table = {
		0: 0,
		170: 0,
		195: 0,
		318: 0,
		319: 0,
		320: 0,
		321: 0,
		737: 0,
		757: 9,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate8(aircraftData):
	table = {
		0: 0,
		737: 0,
		318: 2.05,
		319: 2.05,
		320: 2.05,
		321: 2.05,
		757: 5.45,
		767: 5.45,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal7Gate9(aircraftData):
	table = {
		0: 0,
		737: 0,
		318: 2.4,
		319: 2.4,
		320: 2.4,
		321: 2.4,
		767: 7,
	}

	table330 = {
		0: 9.55,
		200: 9.55,
		300: 12.2,
		800: 9.55,
		900: 12.2,
	}

	table340 = {
		0: 12.2,
		200: 12.2,
		300: 12.2,
		500: 14.45,
		600: 14.45,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			340 : (table330, 0),
			340 : (table340, 0),
		},
		table) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate1(aircraftData):
	table = {
		0: 4.05,
		777: 0,
		787: 0,
		11: 0,
		340: 2,
		330: 2,
		319: 2,
		320: 2,
		170: 2,
		175: 2,
		737: 2,
		321: 2,
		900: 2,
		350: 4,
		747: 4,
		767: 4,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate2(aircraftData):
	table = {
		0: 0,
		747: 2.32,
		767: 2.32,
		11: 12.6,
		787: 12.6,
		380: 12.6,
	}

	table777 = {
		0: 12.6,
		200: 12.6,
		300: 19.22,
	}

	table350 = {
		0: 19.22,
		900: 2.32,
		1000: 19.22,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate3(aircraftData):
	table = {
		0: 0,
		747: 2,
		767: 2,
		11: 7.54,
		787: 7.54,
		380: 7.54,
	}

	table777 = {
		0: 7.54,
		200: 7.54,
		300: 13.78,
	}

	table350 = {
		0: 13.78,
		900: 2,
		1000: 13.78,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate4(aircraftData):
	table = {
		0: 0,
		747: 2,
		767: 2,
		11: 12.98,
		787: 12.98,
		380: 12.98,
	}

	table777 = {
		0: 12.98,
		200: 12.98,
		300: 16.65,
	}

	table350 = {
		0: 16.65,
		900: 2,
		1000: 16.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate5(aircraftData):
	table = {
		0: 0,
		747: 2.87,
		767: 2.87,
		11: 10.4,
		787: 10.4,
		380: 10.4,
	}

	table777 = {
		0: 10.4,
		200: 10.4,
		300: 15.42,
	}

	table350 = {
		0: 15.42,
		900: 2.87,
		1000: 15.42,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate6(aircraftData):
	table = {
		0: 0,
		747: 6.94,
		767: 6.94,
		11: 15.7,
		787: 15.7,
		380: 15.7,
	}

	table777 = {
		0: 15.7,
		200: 15.7,
		300: 21.4,
	}

	table350 = {
		0: 21.4,
		900: 6.94,
		1000: 21.4,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate7(aircraftData):
	table = {
		0: 0,
		747: 2.59,
		767: 2.59,
		11: 7.53,
		787: 7.53,
		380: 7.53,
	}

	table777 = {
		0: 7.53,
		200: 7.53,
		300: 10.42,
	}

	table350 = {
		0: 10.42,
		900: 2.59,
		1000: 10.42,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate8(aircraftData):
	table = {
		0: 0,
		747: 2.29,
		767: 2.29,
		11: 4.71,
		787: 4.71,
		380: 4.71,
	}

	table777 = {
		0: 4.71,
		200: 4.71,
		300: 7.28,
	}

	table350 = {
		0: 7.28,
		900: 2.29,
		1000: 7.28,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate10(aircraftData):
	table = {
		0: 0,
		747: 3.34,
		767: 3.34,
		11: 6.42,
		787: 6.42,
		380: 6.42,
	}

	table777 = {
		0: 6.42,
		200: 6.42,
		300: 12.15,
	}

	table350 = {
		0: 12.15,
		900: 3.34,
		1000: 12.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate12(aircraftData):
	table = {
		0: 0,
		747: 4.8,
		767: 4.8,
		11: 9.13,
		787: 9.13,
		380: 9.13,
	}

	table777 = {
		0: 9.13,
		200: 9.13,
		300: 12.15,
	}

	table350 = {
		0: 12.15,
		900: 4.8,
		1000: 12.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate14(aircraftData):
	table = {
		0: 0,
		747: 4.81,
		767: 4.81,
		11: 19.38,
		787: 19.38,
		380: 19.38,
	}

	table777 = {
		0: 19.38,
		200: 19.38,
		300: 23.15,
	}

	table350 = {
		0: 23.15,
		900: 4.81,
		1000: 23.15,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate16(aircraftData):
	table = {
		0: 0,
		747: 3.12,
		767: 3.12,
		11: 11.99,
		787: 11.99,
		380: 11.99,
	}

	table777 = {
		0: 11.99,
		200: 11.99,
		300: 15.99,
	}

	table350 = {
		0: 15.99,
		900: 3.12,
		1000: 15.99,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate18(aircraftData):
	table = {
		0: 0,
		747: 3.24,
		767: 3.24,
		11: 6.23,
		787: 6.23,
		380: 6.23,
	}

	table777 = {
		0: 6.23,
		200: 6.23,
		300: 11.8,
	}

	table350 = {
		0: 11.8,
		900: 3.24,
		1000: 11.8,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate20(aircraftData):
	table = {
		0: 0,
		747: 3.22,
		767: 3.22,
		11: 6.21,
		787: 6.21,
		380: 6.21,
	}

	table777 = {
		0: 6.21,
		200: 6.21,
		300: 11.74,
	}

	table350 = {
		0: 11.74,
		900: 3.22,
		1000: 11.74,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTerminal8Gate33(aircraftData):
	table = {
		0: 15.5,
		700: 0,
		319: 4.55,
		320: 4.55,
		170: 11.1,
		175: 11.1,
		737: 15.5,
		321: 15.5,
		900: 15.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate34(aircraftData):
	table = {
		0: 16.15,
		700: 0,
		319: 3.1,
		320: 3.1,
		170: 9.85,
		175: 9.85,
		737: 16.15,
		321: 16.15,
		900: 16.15,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate35(aircraftData):
	table = {
		0: 11.1,
		319: 0,
		320: 0,
		170: 4.55,
		175: 4.55,
		737: 11.1,
		321: 11.1,
		900: 11.1,
		767: 15.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate36(aircraftData):
	table = {
		0: 16.25,
		700: 0,
		319: 3.35,
		320: 3.35,
		170: 10.2,
		175: 10.2,
		737: 16.25,
		321: 16.25,
		900: 16.25,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate37(aircraftData):
	table = {
		0: 11.05,
		319: 0,
		320: 0,
		170: 4.5,
		175: 4.5,
		737: 11.05,
		321: 11.05,
		900: 11.05,
		767: 15.45,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate38(aircraftData):
	table = {
		0: 16.9,
		700: 0,
		319: 3.95,
		320: 3.95,
		170: 10.8,
		175: 10.8,
		737: 16.9,
		321: 16.9,
		900: 16.9,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate39(aircraftData):
	table = {
		0: 11.1,
		319: 0,
		320: 0,
		170: 4.5,
		175: 4.5,
		737: 11.1,
		321: 11.1,
		900: 11.1,
		767: 15.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate40(aircraftData):
	table = {
		0: 16.9,
		700: 0,
		319: 4,
		320: 4,
		170: 10.85,
		175: 10.85,
		737: 16.9,
		321: 16.9,
		900: 16.9,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate41(aircraftData):
	table = {
		0: 11.1,
		319: 0,
		320: 0,
		170: 4.5,
		175: 4.5,
		737: 11.1,
		321: 11.1,
		900: 11.1,
		767: 15.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate42(aircraftData):
	table = {
		0: 16.4,
		700: 0,
		319: 3.45,
		320: 3.45,
		170: 10.3,
		175: 10.3,
		737: 16.4,
		321: 16.4,
		900: 16.4,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate43(aircraftData):
	table = {
		0: 11,
		319: 0,
		320: 0,
		170: 4.5,
		175: 4.5,
		737: 11,
		321: 11,
		900: 11,
		767: 15.35,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate44(aircraftData):
	table = {
		0: 11,
		319: 3.55,
		320: 3.55,
		170: 10.4,
		175: 10.4,
		737: 16.45,
		321: 16.45,
		900: 16.45,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate45(aircraftData):
	table = {
		0: 14.95,
		319: 4.8,
		320: 4.8,
		170: 8.4,
		175: 8.4,
		737: 14.95,
		321: 14.95,
		900: 14.95,
		767: 19.35,
		777: 19.35,
		787: 19.35,
		350: 19.35,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate46(aircraftData):
	table = {
		0: 11.15,
		319: 0,
		320: 0,
		170: 4.35,
		175: 4.35,
		737: 11.15,
		321: 11.15,
		900: 11.15,
		767: 17.2,
		777: 17.2,
		787: 17.2,
		350: 17.2,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal8Gate47(aircraftData):
	table = {
		0: 8.9,
		319: 0,
		320: 0,
		170: 2.95,
		175: 2.95,
		737: 8.9,
		321: 8.9,
		900: 8.9,
		767: 17.75,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

def MyTerminalNames(name, letter, priority):
	return CustomizedName( "%s|Gate %s#§" % (name, letter), priority )

def MyStandNames(name, letter, priority):
	return CustomizedName( "%s|Stand %s#§" % (name, letter), priority )

Terminal4ANames = MyTerminalNames("Terminal 4 - Concourse A", "", 3)
Terminal4BNames = MyTerminalNames("Terminal 4 - Concourse B", "", 3)
Terminal4RemoteNames = MyStandNames("Terminal 4 - Remote", "", 3)
Terminal8BNames = MyTerminalNames("Terminal 8 - Concourse B", "", 6)
Terminal8CNames = MyTerminalNames("Terminal 8 - Concourse C", "", 6)
Terminal2Names = MyTerminalNames("Terminal 2", "C", 2)
Terminal2RemoteNames = MyTerminalNames("Terminal 2", "C", 2)
Terminal5Names = MyTerminalNames("Terminal 5", "", 4)
Terminal5HRemoteNames = MyStandNames("Terminal 5 - Remote", "H", 4)
Terminal5RemoteNames = MyStandNames("Terminal 5 - Remote", "", 4)
Terminal1Names = MyTerminalNames("Terminal 1", "", 1)
Terminal7Names = MyTerminalNames("Terminal 7", "", 5)
NCargoNames = MyStandNames("North Cargo Ramp", "", 7)
NWCargoNames = MyStandNames("North West Cargo Ramp", "", 8)
AANames = MyStandNames("American Airlines Maintenance", "", 9)
GANames = MyStandNames("General Aviation Terminal", "", 9)
WestCargoandRONRampNames = MyStandNames("West Cargo and RON Ramp", "", 10)

parkings = {
	GATE_A : {
		None : ( ),
				2 : (Terminal4ANames, customOffsetTerminal4Gate2),
				3 : (Terminal4ANames, customOffsetTerminal4Gate3),
				4 : (Terminal4ANames, customOffsetTerminal4Gate4),
				5 : (Terminal4ANames, customOffsetTerminal4Gate5),
				6 : (Terminal4ANames, customOffsetTerminal4Gate6),
				7 : (Terminal4ANames, ),
				8 : (Terminal4ANames, customOffsetTerminal4Gate8),
				9 : (Terminal4ANames, customOffsetTerminal4Gate9),
				10 : (Terminal4ANames, customOffsetTerminal4Gate101112),
				11 : (Terminal4ANames, customOffsetTerminal4Gate101112),
				12 : (Terminal4ANames, customOffsetTerminal4Gate101112),
				14 : (Terminal4ANames, customOffsetTerminal4Gate14),
				15 : (Terminal4ANames, customOffsetTerminal4Gate15),
				16 : (Terminal4ANames, customOffsetTerminal4Gate16),
				17 : (Terminal4ANames, customOffsetTerminal4Gate17),
				19 : (Terminal4ANames, customOffsetTerminal4Gate19),
				20 : (Terminal4BNames, ),
				21 : (Terminal4ANames, customOffsetTerminal4Gate21),
				22 : (Terminal4BNames, customOffsetTerminal4Gate22),
				24 : (Terminal4BNames, ),
				25 : (Terminal4BNames, ),
				26 : (Terminal4BNames, customOffsetTerminal4Gate26),
				27 : (Terminal4BNames, customOffsetTerminal4Gate27),
				28 : (Terminal4BNames, customOffsetTerminal4Gate28),
				29 : (Terminal4BNames, customOffsetTerminal4Gate29),
				30 : (Terminal4BNames, ),
				31 : (Terminal4BNames, customOffsetTerminal4Gate31),
				32 : (Terminal4BNames, customOffsetTerminal4Gate32),
				33 : (Terminal4BNames, customOffsetTerminal4Gate33),
				34 : (Terminal4BNames, customOffsetTerminal4Gate34),
				35 : (Terminal4BNames, customOffsetTerminal4Gate35),
				36 : (Terminal4BNames, customOffsetTerminal4Gate36),
				37 : (Terminal4BNames, customOffsetTerminal4Gate37),
				38 : (Terminal4BNames, customOffsetTerminal4Gate38),
				39 : (Terminal4BNames, customOffsetTerminal4Gate39),
				41 : (Terminal4BNames, customOffsetTerminal4Gate41),
				42 : (Terminal4BNames, customOffsetTerminal4Gate42444653),
				43 : (Terminal4BNames, customOffsetTerminal4Gate434547),
				44 : (Terminal4BNames, customOffsetTerminal4Gate42444653),
				45 : (Terminal4BNames, customOffsetTerminal4Gate434547),
				46 : (Terminal4BNames, customOffsetTerminal4Gate42444653),
				47 : (Terminal4BNames, customOffsetTerminal4Gate434547),
				48 : (Terminal4BNames, customOffsetTerminal4Gate48),
				49 : (Terminal4BNames, customOffsetTerminal4Gate49),
				51 : (Terminal4BNames, customOffsetTerminal4Gate51),
				53 : (Terminal4BNames, customOffsetTerminal4Gate42444653),
				55 : (Terminal4BNames, customOffsetTerminal4Gate55),
				72 : (Terminal4RemoteNames, ),
				73 : (Terminal4RemoteNames, ),
				74 : (Terminal4RemoteNames, ),
				79 : (Terminal4RemoteNames, ),
				83 : (Terminal4RemoteNames, ),
				84 : (Terminal4RemoteNames, ),
				85 : (Terminal4RemoteNames, ),
				86 : (Terminal4RemoteNames, ),
				87 : (Terminal4RemoteNames, ),
				88 : (Terminal4RemoteNames, ),
				89 : (Terminal4RemoteNames, ),
				90 : (Terminal4RemoteNames, ),
				91 : (Terminal4RemoteNames, ),
				92 : (Terminal4RemoteNames, ),
				93 : (Terminal4RemoteNames, ),
				94 : (Terminal4RemoteNames, ),
				95 : (Terminal4RemoteNames, ),
				96 : (Terminal4RemoteNames, ),
				97 : (Terminal4RemoteNames, ),
	},
	GATE_B : {
		None : ( ),
				1 : (Terminal8BNames, customOffsetTerminal8Gate1),
				"1A" : (Terminal8BNames, customOffsetStands1line),
				"1B" : (Terminal8BNames, customOffsetStands1line),
				"1C" : (Terminal8BNames, customOffsetStands1line),
				"1D" : (Terminal8BNames, customOffsetStands1line),
				2 : (Terminal8BNames, customOffsetTerminal8Gate2),
				3 : (Terminal8BNames, customOffsetTerminal8Gate3),
				4 : (Terminal8BNames, customOffsetTerminal8Gate4),
				5 : (Terminal8BNames, customOffsetTerminal8Gate5),
				6 : (Terminal8BNames, customOffsetTerminal8Gate6),
				7 : (Terminal8BNames, customOffsetTerminal8Gate7),
				8 : (Terminal8BNames, customOffsetTerminal8Gate8),
				10 : (Terminal8BNames, customOffsetTerminal8Gate10),
				12 : (Terminal8BNames, customOffsetTerminal8Gate12),
				14 : (Terminal8BNames, customOffsetTerminal8Gate14),
				16 : (Terminal8BNames, customOffsetTerminal8Gate16),
				18 : (Terminal8BNames, customOffsetTerminal8Gate18),
				20 : (Terminal8BNames, customOffsetTerminal8Gate20),
				31 : (Terminal8CNames, ),
				32 : (Terminal8CNames, ),
				33 : (Terminal8CNames, customOffsetTerminal8Gate33),
				34 : (Terminal8CNames, customOffsetTerminal8Gate34),
				35 : (Terminal8CNames, customOffsetTerminal8Gate35),
				36 : (Terminal8CNames, customOffsetTerminal8Gate36),
				37 : (Terminal8CNames, customOffsetTerminal8Gate37),
				38 : (Terminal8CNames, customOffsetTerminal8Gate38),
				39 : (Terminal8CNames, customOffsetTerminal8Gate39),
				40 : (Terminal8CNames, customOffsetTerminal8Gate40),
				41 : (Terminal8CNames, customOffsetTerminal8Gate41),
				42 : (Terminal8CNames, customOffsetTerminal8Gate42),
				43 : (Terminal8CNames, customOffsetTerminal8Gate43),
				44 : (Terminal8CNames, customOffsetTerminal8Gate44),
				45 : (Terminal8CNames, customOffsetTerminal8Gate45),
				46 : (Terminal8CNames, customOffsetTerminal8Gate46),
				47 : (Terminal8CNames, customOffsetTerminal8Gate47),
	},
	GATE_C : {
		None : ( ),
				60 : (Terminal2Names, ),
				61 : (Terminal2Names, ),
				62 : (Terminal2Names, ),
				63 : (Terminal2Names, ),
				64 : (Terminal2Names, ),
				65 : (Terminal2Names, ),
				66 : (Terminal2Names, ),
				67 : (Terminal2Names, ),
				68 : (Terminal2Names, ),
				69 : (Terminal2Names, ),
				70 : (Terminal2Names, ),
	},
	GATE_D : {
		None : ( ),
				1 : (Terminal5Names, customOffsetTerminal5Gate1),
				2 : (Terminal5Names, customOffsetTerminal5Gate2),
				3 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				4 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				5 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				6 : (Terminal5Names, customOffsetTerminal5Gate6),
				7 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				8 : (Terminal5Names, customOffsetTerminal5Gate81421),
				9 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				10 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				11 : (Terminal5Names, customOffsetTerminal5Gate11),
				12 : (Terminal5Names, customOffsetTerminal5Gate345791012),
				14 : (Terminal5Names, customOffsetTerminal5Gate81421),
				15 : (Terminal5Names, customOffsetTerminal5Gate15),
				16 : (Terminal5Names, customOffsetTerminal5Gate16),
				17 : (Terminal5Names, customOffsetTerminal5Gate17181920),
				18 : (Terminal5Names, customOffsetTerminal5Gate17181920),
				19 : (Terminal5Names, customOffsetTerminal5Gate17181920),
				20 : (Terminal5Names, customOffsetTerminal5Gate17181920),
				21 : (Terminal5Names, customOffsetTerminal5Gate81421),
				22 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				23 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				24 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				25 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				26 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				27 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				28 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				29 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
				30 : (Terminal5Names, customOffsetTerminal5Gate222324252627282930),
	},
	GATE_E : {
		None : ( ),
				1 : (Terminal1Names, customOffsetTerminal1Gate1),
				2 : (Terminal1Names, customOffsetTerminal1Gate2),
				3 : (Terminal1Names, customOffsetTerminal1Gate3),
				4 : (Terminal1Names, customOffsetTerminal1Gate4),
				5 : (Terminal1Names, customOffsetTerminal1Gate5),
				6 : (Terminal1Names, customOffsetTerminal1Gate6),
				7 : (Terminal1Names, customOffsetTerminal1Gate7),
				8 : (Terminal1Names, customOffsetTerminal1Gate8),
				9 : (Terminal1Names, customOffsetTerminal1Gate9),
				10 : (Terminal1Names, customOffsetTerminal1Gate10),
	},
	GATE_F : {
		None : ( ),
				1 : (Terminal7Names, customOffsetTerminal7Gate1),
				2 : (Terminal7Names, customOffsetTerminal7Gate2),
				3 : (Terminal7Names, customOffsetTerminal7Gate3),
				4 : (Terminal7Names, customOffsetTerminal7Gate4),
				5 : (Terminal7Names, customOffsetTerminal7Gate5),
				6 : (Terminal7Names, customOffsetTerminal7Gate6),
				7 : (Terminal7Names, customOffsetTerminal7Gate7),
				8 : (Terminal7Names, customOffsetTerminal7Gate8),
				9 : (Terminal7Names, customOffsetTerminal7Gate9),
	},
	GATE_H : {
		None : ( ),
				1 : (Terminal5HRemoteNames, ),
				2 : (Terminal5HRemoteNames, ),
				3 : (Terminal5HRemoteNames, ),
				4 : (Terminal5HRemoteNames, ),
				5 : (Terminal5HRemoteNames, ),
				6 : (Terminal5HRemoteNames, ),
				9 : (Terminal5HRemoteNames, ),
				10 : (Terminal5HRemoteNames, ),
				12 : (Terminal5HRemoteNames, ),
				61 : (Terminal4RemoteNames, ),
				63 : (Terminal4RemoteNames, ),
	},
	N_PARKING : {
		None : ( ),
				1 : (NCargoNames, ),
				2 : (NCargoNames, ),
				3 : (NCargoNames, ),
				4 : (NCargoNames, ),
				5 : (NCargoNames, ),
				248 : (NCargoNames, ),
	},
	NW_PARKING : {
		None : ( ),
				1 : (NWCargoNames, ),
				2 : (NWCargoNames, ),
				3 : (NWCargoNames, ),
				4 : (NWCargoNames, ),
				5 : (NWCargoNames, ),
				6 : (NWCargoNames, ),
				7 : (NWCargoNames, ),
				212 : (AANames, ),
				213 : (AANames, ),
				214 : (AANames, ),
				215 : (AANames, ),
				216 : (AANames, ),
				217 : (AANames, ),
				219 : (AANames, ),
				220 : (AANames, ),
				222 : (NWCargoNames, ),
				223 : (NWCargoNames, ),
				224 : (NWCargoNames, ),
				225 : (NWCargoNames, ),
				226 : (NWCargoNames, ),
				227 : (NWCargoNames, ),
				228 : (NWCargoNames, ),
				229 : (NWCargoNames, ),
				230 : (NWCargoNames, ),
				231 : (NWCargoNames, ),
				232 : (NWCargoNames, ),
				234 : (NWCargoNames, ),
				235 : (NWCargoNames, ),
				236 : (NWCargoNames, ),
				237 : (NWCargoNames, ),
				263 : (NWCargoNames, ),
	},
	PARKING : {
		None : ( ),
				1 : (GANames, ),
				2 : (GANames, ),
				3 : (GANames, ),
				89 : (Terminal5RemoteNames, ),
				90 : (Terminal5RemoteNames, ),
				91 : (Terminal5RemoteNames, ),
				97 : (Terminal4RemoteNames, ),
				99 : (Terminal4RemoteNames, ),
				125 : (Terminal2RemoteNames, ),
				126 : (Terminal2RemoteNames, ),
	},
	W_PARKING : {
		None : ( ),
				1 : (WestCargoandRONRampNames, ),
				2 : (WestCargoandRONRampNames, ),
				3 : (WestCargoandRONRampNames, ),
				4 : (WestCargoandRONRampNames, ),
				5 : (WestCargoandRONRampNames, ),
				6 : (WestCargoandRONRampNames, ),
				7 : (WestCargoandRONRampNames, ),
				8 : (WestCargoandRONRampNames, ),
				9 : (WestCargoandRONRampNames, ),
				10 : (WestCargoandRONRampNames, ),
				11 : (WestCargoandRONRampNames, ),
				12 : (WestCargoandRONRampNames, ),
				13 : (WestCargoandRONRampNames, ),
				14 : (WestCargoandRONRampNames, ),
				15 : (WestCargoandRONRampNames, ),
				16 : (WestCargoandRONRampNames, ),
				"16B" : (WestCargoandRONRampNames, ),
				"16C" : (WestCargoandRONRampNames, ),
				"16A" : (WestCargoandRONRampNames, ),
				"18F" : (WestCargoandRONRampNames, ),
				"19B" : (WestCargoandRONRampNames, ),
				"19A" : (WestCargoandRONRampNames, ),
				"19C" : (WestCargoandRONRampNames, ),
				20 : (WestCargoandRONRampNames, ),
	},
}