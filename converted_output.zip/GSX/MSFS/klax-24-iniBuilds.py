# -- coding: utf-8 --

msfs_mode = 1
icao = "klax"

def HandleAircraftOffsets(aircraftData, specificTables, genericTable):
	major_id = aircraftData.idMajor
	minor_id = aircraftData.idMinor

	if major_id in specificTables:
		specific_table, fallback_key = specificTables[major_id]
		result = specific_table.get(minor_id)
		if result is None:
			result = specific_table.get(fallback_key)
	else:
		result = genericTable.get(major_id, 0)

	return result

@AlternativeStopPositions
def customOffsetStands1line(aircraftData):

	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTBITGate130(aircraftData):
	table = {
		0: 0,
		757: 3.76,
		767: 3.76,
		11: 3.76,
		380: 7.1,
		747: 7.1,
		350: 11.28,
		777: 11.28,
	}

	table330 = {
		0: 3.76,
		200: 3.76,
		800: 3.76,
		300: 7.1,
		900: 7.1,
	}

	table787 = {
		0: 7.1,
		8: 7.1,
		9: 7.1,
		10: 11.28,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate131(aircraftData):
	table = {
		0: 0,
		757: 5,
		767: 5,
		11: 5,
		380: 8.75,
		747: 8.75,
		350: 12.09,
		777: 12.09,
	}

	table330 = {
		0: 5,
		200: 5,
		800: 5,
		300: 8.75,
		900: 8.75,
	}

	table787 = {
		0: 8.75,
		8: 8.75,
		9: 8.75,
		10: 12.09,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate132(aircraftData):
	table = {
		0: 0,
		757: 9.1,
		767: 9.1,
		11: 9.1,
		380: 11.45,
		747: 11.45,
		350: 16.01,
		777: 16.01,
	}

	table330 = {
		0: 9.1,
		200: 9.1,
		800: 9.1,
		300: 11.45,
		900: 11.45,
	}

	table787 = {
		0: 11.45,
		8: 11.45,
		9: 11.45,
		10: 16.01,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate133(aircraftData):
	table = {
		0: 0,
		757: 5.1,
		767: 5.1,
		11: 5.1,
		380: 8.88,
		747: 8.88,
		350: 12.2,
		777: 12.2,
	}

	table330 = {
		0: 5.1,
		200: 5.1,
		800: 5.1,
		300: 8.88,
		900: 8.88,
	}

	table787 = {
		0: 8.88,
		8: 8.88,
		9: 8.88,
		10: 12.2,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate134(aircraftData):
	table = {
		0: 0,
		757: 3.48,
		767: 3.48,
		11: 3.48,
		380: 6.59,
		747: 6.59,
		350: 9.59,
		777: 9.59,
	}

	table330 = {
		0: 3.48,
		200: 3.48,
		800: 3.48,
		300: 6.59,
		900: 6.59,
	}

	table787 = {
		0: 6.59,
		8: 6.59,
		9: 6.59,
		10: 9.59,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate137(aircraftData):

	table = {
		0: 0,
		737: 1.79,
		320: 1.79,
		321: 1.79,
		757: 1.79,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTBITGate139(aircraftData):

	table = {
		0: 0,
		737: 1.85,
		320: 1.85,
		321: 5.69,
		757: 5.69,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTBITGate141(aircraftData):

	table = {
		0: 0,
		737: 1.5,
		320: 1.5,
		321: 4.97,
		757: 4.97,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetTBITGate148(aircraftData):
	table = {
		0: 0,
		757: 4.07,
		767: 4.07,
		11: 4.07,
		380: 5.79,
		747: 5.79,
		350: 10.35,
		777: 10.35,
	}

	table330 = {
		0: 4.07,
		200: 4.07,
		800: 4.07,
		300: 5.79,
		900: 5.79,
	}

	table787 = {
		0: 5.79,
		8: 5.79,
		9: 5.79,
		10: 10.35,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate150(aircraftData):
	table = {
		0: 0,
		757: 4.07,
		767: 4.07,
		11: 4.07,
		380: 5.79,
		747: 5.79,
		350: 10.35,
		777: 10.35,
	}

	table330 = {
		0: 4.07,
		200: 4.07,
		800: 4.07,
		300: 5.79,
		900: 5.79,
	}

	table787 = {
		0: 5.79,
		8: 5.79,
		9: 5.79,
		10: 10.35,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate151(aircraftData):
	table = {
		0: 0,
		757: 5.31,
		767: 5.31,
		11: 5.31,
		380: 8.99,
		747: 8.99,
		350: 13.78,
		777: 13.78,
	}

	table330 = {
		0: 5.31,
		200: 5.31,
		800: 5.31,
		300: 8.99,
		900: 8.99,
	}

	table787 = {
		0: 8.99,
		8: 8.99,
		9: 8.99,
		10: 13.78,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate152(aircraftData):
	table = {
		0: 0,
		757: 4.02,
		767: 4.02,
		11: 4.02,
		380: 5.73,
		747: 5.73,
		350: 10.31,
		777: 10.31,
	}

	table330 = {
		0: 4.02,
		200: 4.02,
		800: 4.02,
		300: 5.73,
		900: 5.73,
	}

	table787 = {
		0: 5.73,
		8: 5.73,
		9: 5.73,
		10: 10.31,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate153(aircraftData):
	table = {
		0: 0,
		757: 4.7,
		767: 4.7,
		11: 4.7,
		380: 9.7,
		747: 9.7,
		350: 14.69,
		777: 14.69,
	}

	table330 = {
		0: 4.7,
		200: 4.7,
		800: 4.7,
		300: 9.7,
		900: 9.7,
	}

	table787 = {
		0: 9.7,
		8: 9.7,
		9: 9.7,
		10: 14.69,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate154(aircraftData):
	table = {
		0: 0,
		757: 4.03,
		767: 4.03,
		11: 4.03,
		380: 5.77,
		747: 5.77,
		350: 10.34,
		777: 10.34,
	}

	table330 = {
		0: 4.03,
		200: 4.03,
		800: 4.03,
		300: 5.77,
		900: 5.77,
	}

	table787 = {
		0: 5.77,
		8: 5.77,
		9: 5.77,
		10: 10.34,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate155(aircraftData):
	table = {
		0: 0,
		757: 4.71,
		767: 4.71,
		11: 4.71,
		380: 9.61,
		747: 9.61,
		350: 14.49,
		777: 14.49,
	}

	table330 = {
		0: 4.71,
		200: 4.71,
		800: 4.71,
		300: 9.61,
		900: 9.61,
	}

	table787 = {
		0: 9.61,
		8: 9.61,
		9: 9.61,
		10: 14.49,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate156(aircraftData):
	table = {
		0: 0,
		757: 4.09,
		767: 4.09,
		11: 4.09,
		380: 5.79,
		747: 5.79,
		350: 10.42,
		777: 10.42,
	}

	table330 = {
		0: 4.09,
		200: 4.09,
		800: 4.09,
		300: 5.79,
		900: 5.79,
	}

	table787 = {
		0: 5.79,
		8: 5.79,
		9: 5.79,
		10: 10.42,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate157(aircraftData):
	table = {
		0: 0,
		757: 4.7,
		767: 4.7,
		11: 4.7,
		380: 9.68,
		747: 9.68,
		350: 14.57,
		777: 14.57,
	}

	table330 = {
		0: 4.7,
		200: 4.7,
		800: 4.7,
		300: 9.68,
		900: 9.68,
	}

	table787 = {
		0: 9.68,
		8: 9.68,
		9: 9.68,
		10: 14.57,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate159(aircraftData):
	table = {
		0: 0,
		757: 4.67,
		767: 4.67,
		11: 4.67,
		380: 9.6,
		747: 9.6,
		350: 9.6,
		777: 9.6,
	}

	table330 = {
		0: 4.67,
		200: 4.67,
		800: 4.67,
		300: 9.6,
		900: 9.6,
	}

	table787 = {
		0: 9.6,
		8: 9.6,
		9: 9.6,
		10: 9.6,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate201A(aircraftData):
	table = {
		0: 0,
		757: 2.04,
		767: 2.04,
		11: 2.04,
		380: 3.9,
		747: 3.9,
		350: 7.28,
		777: 7.28,
	}

	table330 = {
		0: 2.04,
		200: 2.04,
		800: 2.04,
		300: 3.9,
		900: 3.9,
	}

	table787 = {
		0: 3.9,
		8: 3.9,
		9: 3.9,
		10: 7.28,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate201B(aircraftData):
	table = {
		0: 0,
		757: 1.85,
		767: 1.85,
		11: 1.85,
		380: 3.04,
		747: 3.04,
		350: 6.01,
		777: 6.01,
	}

	table330 = {
		0: 1.85,
		200: 1.85,
		800: 1.85,
		300: 3.04,
		900: 3.04,
	}

	table787 = {
		0: 3.04,
		8: 3.04,
		9: 3.04,
		10: 6.01,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate202(aircraftData):
	table = {
		0: 0,
		757: 5.01,
		767: 5.01,
		11: 5.01,
		380: 12.96,
		747: 12.96,
		350: 20.05,
		777: 20.05,
	}

	table330 = {
		0: 5.01,
		200: 5.01,
		800: 5.01,
		300: 12.96,
		900: 12.96,
	}

	table787 = {
		0: 12.96,
		8: 12.96,
		9: 12.96,
		10: 20.05,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate203(aircraftData):
	table = {
		0: 0,
		757: 6.51,
		767: 6.51,
		11: 6.51,
		380: 13.86,
		747: 13.86,
		350: 20.58,
		777: 20.58,
	}

	table330 = {
		0: 6.51,
		200: 6.51,
		800: 6.51,
		300: 13.86,
		900: 13.86,
	}

	table787 = {
		0: 13.86,
		8: 13.86,
		9: 13.86,
		10: 20.58,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate204(aircraftData):
	table = {
		0: 0,
		757: 5.01,
		767: 5.01,
		11: 5.01,
		380: 12.98,
		747: 12.98,
		350: 20.05,
		777: 20.05,
	}

	table330 = {
		0: 5.01,
		200: 5.01,
		800: 5.01,
		300: 12.98,
		900: 12.98,
	}

	table787 = {
		0: 12.98,
		8: 12.98,
		9: 12.98,
		10: 20.05,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate205(aircraftData):
	table = {
		0: 0,
		757: 4.91,
		767: 4.91,
		11: 4.91,
		380: 15.11,
		747: 15.11,
		350: 24.45,
		777: 24.45,
	}

	table330 = {
		0: 4.91,
		200: 4.91,
		800: 4.91,
		300: 15.11,
		900: 15.11,
	}

	table787 = {
		0: 15.11,
		8: 15.11,
		9: 15.11,
		10: 24.45,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate206(aircraftData):
	table = {
		0: 0,
		757: 4.96,
		767: 4.96,
		11: 4.96,
		380: 12.93,
		747: 12.93,
		350: 20.04,
		777: 20.04,
	}

	table330 = {
		0: 4.96,
		200: 4.96,
		800: 4.96,
		300: 12.93,
		900: 12.93,
	}

	table787 = {
		0: 12.93,
		8: 12.93,
		9: 12.93,
		10: 20.04,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate207(aircraftData):
	table = {
		0: 0,
		757: 13.52,
		767: 13.52,
		11: 13.52,
		380: 19.3,
		747: 19.3,
		350: 22.85,
		777: 22.85,
	}

	table330 = {
		0: 13.52,
		200: 13.52,
		800: 13.52,
		300: 19.3,
		900: 19.3,
	}

	table787 = {
		0: 19.3,
		8: 19.3,
		9: 19.3,
		10: 22.85,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate208(aircraftData):
	table = {
		0: 0,
		757: 5.01,
		767: 5.01,
		11: 5.01,
		380: 14.68,
		747: 14.68,
		350: 20.05,
		777: 20.05,
	}

	table330 = {
		0: 5.01,
		200: 5.01,
		800: 5.01,
		300: 14.68,
		900: 14.68,
	}

	table787 = {
		0: 14.68,
		8: 14.68,
		9: 14.68,
		10: 20.05,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate209(aircraftData):
	table = {
		0: 0,
		757: 5.48,
		767: 5.48,
		11: 5.48,
		380: 12.65,
		747: 12.65,
		350: 19.82,
		777: 19.82,
	}

	table330 = {
		0: 5.48,
		200: 5.48,
		800: 5.48,
		300: 12.65,
		900: 12.65,
	}

	table787 = {
		0: 12.65,
		8: 12.65,
		9: 12.65,
		10: 19.82,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate210B(aircraftData):
	table = {
		0: 0,
		757: 1.75,
		767: 1.75,
		11: 1.75,
		380: 3.87,
		747: 3.87,
		350: 5.02,
		777: 5.02,
	}

	table330 = {
		0: 1.75,
		200: 1.75,
		800: 1.75,
		300: 3.87,
		900: 3.87,
	}

	table787 = {
		0: 3.87,
		8: 3.87,
		9: 3.87,
		10: 5.02,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate210A(aircraftData):
	table = {
		0: 0,
		757: 5.54,
		767: 5.54,
		11: 5.54,
		380: 7.24,
		747: 7.24,
		350: 8.25,
		777: 8.25,
	}

	table330 = {
		0: 5.54,
		200: 5.54,
		800: 5.54,
		300: 7.24,
		900: 7.24,
	}

	table787 = {
		0: 7.24,
		8: 7.24,
		9: 7.24,
		10: 8.25,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate221(aircraftData):
	table = {
		0: 0,
		757: 13.47,
		767: 13.47,
		11: 13.47,
		380: 16.48,
		747: 16.48,
		350: 22.28,
		777: 22.28,
	}

	table330 = {
		0: 13.47,
		200: 13.47,
		800: 13.47,
		300: 16.48,
		900: 16.48,
	}

	table787 = {
		0: 16.48,
		8: 16.48,
		9: 16.48,
		10: 22.28,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetTBITGate225(aircraftData):
	table = {
		0: 0,
		757: 3.27,
		767: 3.27,
		11: 3.27,
		380: 15.01,
		747: 15.01,
		350: 20.32,
		777: 20.32,
	}

	table330 = {
		0: 3.27,
		200: 3.27,
		800: 3.27,
		300: 15.01,
		900: 15.01,
	}

	table787 = {
		0: 15.01,
		8: 15.01,
		9: 15.01,
		10: 20.32,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			330 : (table330, 0),
			787 : (table787, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT1Gate11B(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.1,
		900: 3.1,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate11A(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.16,
		900: 3.16,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate12B(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.47,
		900: 3.47,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate12A(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.7,
		900: 3.7,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate13(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.01,
		900: 3.01,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate14(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.1,
		900: 3.1,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate15(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 2.98,
		900: 2.98,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate16(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.79,
		900: 3.79,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate17B(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.29,
		900: 3.29,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate17A(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.38,
		900: 3.38,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate18B(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 4.39,
		900: 4.39,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT1Gate18A(aircraftData):

	table = {
		0: 0,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.66,
		900: 3.66,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT2Gate21(aircraftData):
	table = {
		0: 0,
		321: 3.08,
		757: 3.08,
		767: 3.08,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT2Gate22(aircraftData):
	table = {
		0: 0,
		319: 1.78,
		320: 4.07,
		321: 6.43,
		767: 8.48,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 4.07,
		900: 4.07,
	}

	table757 = {
		0: 6.43,
		200: 6.43,
		300: 8.48,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT2Gate23A(aircraftData):
	table = {
		0: 0,
		321: 2.05,
		320: 2.05,
		737: 2.05,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT2Gate23B(aircraftData):
	table = {
		0: 0,
		319: 2.01,
		717: 2.01,
		737: 4.29,
		320: 4.29,
		767: 5.05,
		757: 5.05,
		321: 5.05,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT2Gate24(aircraftData):
	table = {
		0: 0,
		319: 3.98,
		320: 6.73,
		321: 12.54,
		767: 18.91,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 6.73,
		900: 6.73,
	}

	table757 = {
		0: 12.54,
		200: 12.54,
		300: 18.91,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT2Gate25(aircraftData):
	table = {
		0: 0,
		319: 3.2,
		717: 4.54,
		737: 4.54,
		320: 4.54,
		767: 8.88,
		757: 8.88,
		321: 8.88,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT2Gate25B(aircraftData):
	table = {
		0: 0,
		319: 1.32,
		717: 1.32,
		737: 2.33,
		320: 2.33,
		767: 3.36,
		757: 3.36,
		321: 3.36,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT2Gate26(aircraftData):
	table = {
		0: 0,
		319: 3.13,
		320: 7.33,
		321: 8.68,
		767: 11.08,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 7.33,
		900: 7.33,
	}

	table757 = {
		0: 8.68,
		200: 8.68,
		300: 11.08,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT2Gate26B(aircraftData):
	table = {
		0: 0,
		737: 1.78,
		320: 1.78,
		767: 1.78,
		757: 1.78,
		321: 1.78,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT2Gate27(aircraftData):
	table = {
		0: 0,
		319: 2.25,
		320: 5.71,
		321: 8.28,
		767: 8.28,
	}

	table737 = {
		200: 0,
		300: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 5.71,
		900: 5.71,
	}

	table757 = {
		0: 8.28,
		200: 8.28,
		300: 8.28,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT2Gate28(aircraftData):
	table = {
		0: 0,
		319: 1.6,
		717: 3.48,
		737: 3.48,
		320: 3.48,
		767: 4.95,
		757: 4.95,
		321: 4.95,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT3Gate30(aircraftData):
	table = {
		0: 0,
		737: 6.88,
		320: 6.88,
		321: 10.75,
		767: 14.43,
		330: 14.43,
		350: 14.43,
	}

	table757 = {
		0: 10.75,
		200: 10.75,
		300: 14.43,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate30B(aircraftData):
	table = {
		0: 0,
		737: 2.72,
		320: 2.72,
		767: 5.05,
		757: 5.05,
		321: 5.05,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT3Gate31A(aircraftData):
	table = {
		0: 0,
		737: 1.12,
		320: 1.12,
		767: 2.25,
		757: 1.12,
		321: 1.12,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT3Gate31B(aircraftData):
	table = {
		0: 0,
		737: 2.42,
		320: 2.42,
		767: 4.13,
		757: 2.42,
		321: 2.42,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT3Gate32B(aircraftData):
	table = {
		0: 0,
		737: 1.58,
		320: 1.58,
		767: 7.01,
		757: 4.44,
		321: 4.44,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT3Gate32(aircraftData):
	table = {
		0: 0,
		737: 2.99,
		320: 2.99,
		321: 7.5,
		767: 11.18,
		330: 11.18,
		350: 11.18,
	}

	table757 = {
		0: 7.5,
		200: 7.5,
		300: 11.18,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate33(aircraftData):
	table = {
		0: 0,
		737: 1.45,
		320: 1.45,
		321: 3.02,
		767: 8.32,
		330: 8.32,
		350: 8.32,
	}

	table757 = {
		0: 3.02,
		200: 3.02,
		300: 8.32,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate34(aircraftData):
	table = {
		0: 0,
		737: 3.04,
		320: 3.04,
		321: 5.19,
		767: 7.8,
		330: 7.8,
		350: 7.8,
	}

	table757 = {
		0: 5.19,
		200: 5.19,
		300: 7.8,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate34B(aircraftData):
	table = {
		0: 0,
		737: 1.75,
		320: 1.75,
		321: 3.3,
		767: 4.88,
		330: 4.88,
		350: 4.88,
	}

	table757 = {
		0: 3.3,
		200: 3.3,
		300: 4.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate35(aircraftData):
	table = {
		0: 0,
		737: 2.3,
		320: 2.3,
		321: 3.99,
		767: 5.59,
		330: 5.59,
		350: 5.59,
	}

	table757 = {
		0: 3.99,
		200: 3.99,
		300: 5.59,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate36(aircraftData):
	table = {
		0: 0,
		321: 2.22,
		767: 4.12,
		330: 4.12,
		350: 4.12,
	}

	table757 = {
		0: 2.22,
		200: 2.22,
		300: 4.12,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate37(aircraftData):
	table = {
		0: 0,
		737: 1.78,
		320: 1.78,
		321: 2.96,
		767: 4.2,
		330: 4.2,
		350: 4.2,
	}

	table757 = {
		0: 2.96,
		200: 2.96,
		300: 4.2,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate38(aircraftData):
	table = {
		0: 0,
		321: 1.78,
		767: 3.8,
		330: 3.8,
		350: 3.8,
	}

	table757 = {
		0: 1.78,
		200: 1.78,
		300: 3.8,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT3Gate37B(aircraftData):
	table = {
		0: 0,
		321: 2.39,
		767: 4.34,
		330: 4.34,
		350: 4.34,
	}

	table757 = {
		0: 2.39,
		200: 2.39,
		300: 4.34,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT4Gate40(aircraftData):

	table = {
		0: 0,
		170: 2.42,
		175: 2.42,
		190: 2.42,
		195: 2.42,
		737: 6.07,
		321: 7.89,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate41(aircraftData):

	table = {
		0: 0,
		787: 3.98,
	}

	table777 = {
		0: 10.1,
		200: 3.98,
		300: 10.1,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {777 : (table777, 300)}, table) )

@AlternativeStopPositions
def customOffsetT4Gate42A(aircraftData):

	table = {
		0: 0,
		170: 3.14,
		175: 3.14,
		190: 3.14,
		195: 3.14,
		737: 6.19,
		321: 8.51,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate42B(aircraftData):

	table = {
		0: 0,
		170: 1.6,
		175: 1.6,
		190: 1.6,
		195: 1.6,
		737: 3.08,
		321: 4.6,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate43(aircraftData):

	table = {
		0: 0,
		787: 4.25,
	}

	table777 = {
		0: 10.78,
		200: 4.25,
		300: 10.78,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {777 : (table777, 300)}, table) )

@AlternativeStopPositions
def customOffsetT4Gate45(aircraftData):

	table = {
		0: 0,
		170: 5.67,
		175: 5.67,
		190: 5.67,
		195: 5.67,
		737: 7.38,
		321: 11.85,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate46B(aircraftData):

	table = {
		0: 0,
		170: 1.1,
		175: 1.1,
		190: 1.1,
		195: 1.1,
		737: 2.25,
		321: 4.47,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate46C(aircraftData):

	table = {
		0: 0,
		170: 1.76,
		175: 1.76,
		190: 1.76,
		195: 1.76,
		737: 3.99,
		321: 8.27,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate47B(aircraftData):

	table = {
		0: 0,
		170: 2.88,
		175: 2.88,
		190: 2.88,
		195: 2.88,
		737: 5.01,
		321: 5.01,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate47A(aircraftData):

	table = {
		0: 0,
		170: 2.87,
		175: 2.87,
		190: 2.87,
		195: 2.87,
		737: 5.01,
		321: 9.21,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate48A(aircraftData):

	table = {
		0: 0,
		170: 2.64,
		175: 2.64,
		190: 2.64,
		195: 2.64,
		737: 5.17,
		321: 9.78,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate48X(aircraftData):

	table = {
		0: 0,
		170: 0.95,
		175: 0.95,
		190: 0.95,
		195: 0.95,
		737: 1.78,
		321: 5.21,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate49A(aircraftData):

	table = {
		0: 0,
		170: 2.08,
		175: 2.08,
		190: 2.08,
		195: 2.08,
		737: 3.85,
		321: 8.11,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT4Gate49B(aircraftData):

	table = {
		0: 0,
		170: 1.57,
		175: 1.57,
		190: 1.57,
		195: 1.57,
		737: 3.71,
		321: 6.93,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate50(aircraftData):

	table = {
		0: 0,
		170: 1.75,
		175: 1.75,
		190: 4.43,
		195: 4.43,
		220: 4.43,
		319: 4.43,
		82: 4.43,
		83: 4.43,
		88: 4.43,
		737: 6.78,
		320: 6.78,
		321: 9.27,
		757: 9.27,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate51B(aircraftData):

	table = {
		0: 0,
		170: 2.12,
		175: 2.12,
		190: 4.67,
		195: 4.67,
		220: 4.67,
		319: 4.67,
		82: 4.67,
		83: 4.67,
		88: 4.67,
		737: 8.56,
		320: 8.56,
		321: 11.96,
		757: 11.96,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate53B(aircraftData):

	table = {
		0: 0,
		170: 1.65,
		175: 1.65,
		190: 3.52,
		195: 3.52,
		220: 3.52,
		319: 3.52,
		82: 3.52,
		83: 3.52,
		88: 3.52,
		737: 5.12,
		320: 5.12,
		321: 8.25,
		757: 8.25,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate54A(aircraftData):

	table = {
		0: 0,
		170: 2.02,
		175: 2.02,
		190: 4.6,
		195: 4.6,
		220: 4.6,
		319: 4.6,
		82: 4.6,
		83: 4.6,
		88: 4.6,
		737: 7.07,
		320: 7.07,
		321: 9.53,
		757: 9.53,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate54B(aircraftData):

	table = {
		0: 0,
		170: 1.9,
		175: 1.9,
		190: 3.43,
		195: 3.43,
		220: 3.43,
		319: 3.43,
		82: 3.43,
		83: 3.43,
		88: 3.43,
		737: 5.3,
		320: 5.3,
		321: 8.6,
		757: 8.6,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate55A(aircraftData):

	table = {
		0: 0,
		170: 1.64,
		175: 1.64,
		190: 3.8,
		195: 3.8,
		220: 3.8,
		319: 3.8,
		82: 3.8,
		83: 3.8,
		88: 3.8,
		737: 6.43,
		320: 6.43,
		321: 8.22,
		757: 8.22,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate56B(aircraftData):

	table = {
		0: 0,
		170: 2.04,
		175: 2.04,
		190: 4.01,
		195: 4.01,
		220: 4.01,
		319: 4.01,
		82: 4.01,
		83: 4.01,
		88: 4.01,
		737: 6.01,
		320: 6.01,
		321: 11.12,
		757: 11.12,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate56A(aircraftData):

	table = {
		0: 0,
		170: 2.04,
		175: 2.04,
		190: 3.59,
		195: 3.59,
		220: 3.59,
		319: 3.59,
		82: 3.59,
		83: 3.59,
		88: 3.59,
		737: 5.69,
		320: 5.69,
		321: 10.77,
		757: 10.77,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate57(aircraftData):

	table = {
		0: 0,
		737: 1.49,
		320: 1.49,
		321: 2.88,
		757: 2.88,
		777: 8.6,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT5Gate59(aircraftData):

	table = {
		0: 0,
		170: 2.7,
		175: 2.7,
		190: 3.99,
		195: 3.99,
		220: 3.99,
		319: 3.99,
		82: 3.99,
		83: 3.99,
		88: 3.99,
		737: 5.2,
		320: 5.2,
		321: 7.33,
		757: 7.33,
		767: 7.33,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate60(aircraftData):

	table = {
		0: 0,
		190: 1.32,
		195: 1.32,
		220: 1.32,
		319: 1.32,
		82: 1.32,
		83: 1.32,
		88: 1.32,
		737: 2.32,
		320: 2.32,
		321: 3.99,
		757: 3.99,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate62(aircraftData):

	table = {
		0: 0,
		220: 4.06,
		319: 4.06,
		82: 4.06,
		83: 4.06,
		88: 4.06,
		737: 4.06,
		320: 4.06,
		321: 6.45,
		757: 6.45,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate64(aircraftData):

	table = {
		0: 0,
		190: 2.34,
		195: 2.34,
		220: 2.34,
		319: 2.34,
		82: 4.41,
		83: 4.41,
		88: 4.41,
		737: 4.41,
		320: 4.41,
		321: 6.68,
		757: 6.68,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate65B(aircraftData):

	table = {
		0: 0,
		190: 1.61,
		195: 1.61,
		220: 1.61,
		319: 1.61,
		82: 4.32,
		83: 4.32,
		88: 4.32,
		737: 4.32,
		320: 4.32,
		321: 6.13,
		757: 6.13,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate65C(aircraftData):

	table = {
		0: 0,
		190: 1.48,
		195: 1.48,
		220: 1.48,
		319: 1.48,
		82: 3.67,
		83: 3.67,
		88: 3.67,
		737: 3.67,
		320: 3.67,
		321: 5.47,
		757: 5.47,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate66(aircraftData):

	table = {
		0: 0,
		82: 2.03,
		83: 2.03,
		88: 2.03,
		737: 2.03,
		320: 2.03,
		321: 3.61,
		757: 3.61,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate67(aircraftData):

	table = {
		0: 0,
		190: 2.62,
		195: 2.62,
		220: 2.62,
		319: 2.62,
		737: 4.16,
		320: 4.16,
		321: 5.81,
		757: 5.81,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT6Gate68B(aircraftData):

	table = {
		0: 0,
		190: 4.25,
		195: 4.25,
		220: 4.25,
		319: 4.25,
		737: 7.41,
		320: 7.41,
		321: 10.29,
		757: 10.29,
		767: 12.42,
		330: 12.42,
		787: 12.42,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT7Gate70A(aircraftData):

	table = {
		0: 0,
		737: 3.78,
		320: 3.78,
		321: 5.05,
	}

	table757 = {
		0: 5.05,
		200: 5.05,
		300: 9.89,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate70B(aircraftData):

	table = {
		0: 0,
		737: 2.51,
		320: 2.51,
		321: 5.54,
	}

	table757 = {
		0: 5.54,
		200: 5.54,
		300: 9.82,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate71B(aircraftData):

	table = {
		0: 0,
		320: 1.8,
		321: 9.92,
	}

	table737 = {
		0: 1.8,
		800: 1.8,
		900: 4.8,
	}


	table757 = {
		0: 9.92,
		200: 9.92,
		300: 15.73,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT7Gate71A(aircraftData):

	table = {
		0: 0,
	}

	table757 = {
		0: 3.62,
		200: 3.62,
		300: 9.3,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate72W(aircraftData):

	table = {
		0: 0,
		737: 2.38,
		320: 2.38,
		321: 5.21,
		777: 9.19,
		787: 9.19,
		767: 9.19,
	}

	table757 = {
		0: 5.21,
		200: 5.21,
		300: 9.19,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate72B(aircraftData):

	table = {
		0: 0,
		737: 2.41,
		320: 2.41,
		321: 5.2,
	}

	table757 = {
		0: 5.2,
		200: 5.2,
		300: 9.12,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate73(aircraftData):

	table = {
		0: 0,
		320: 1.71,
		321: 4.8,
	}

	table737 = {
		0: 1.71,
		800: 1.71,
		900: 4.8,
	}


	table757 = {
		0: 10.41,
		200: 10.41,
		300: 15.82,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT7Gate74(aircraftData):

	table = {
		0: 0,
		320: 4.98,
		321: 6.89,
		330: 6.89,
		737: 6.89,
		757: 12.14,
	}

	table787 = {
		0: 12.14,
		8: 12.14,
		9: 12.14,
		10: 18.42,
	}

	table777 = {
		0: 10.41,
		200: 14,
		300: 18.42,
	}

	table767 = {
		0: 8.02,
		300: 8.02,
		400: 14,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			787 : (table787, 0),
			777 : (table777, 0),
			767 : (table767, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT7Gate75B(aircraftData):

	table = {
		0: 0,
		321: 5.98,
	}

	table757 = {
		0: 5.98,
		200: 5.98,
		300: 12.39,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate75A(aircraftData):

	table = {
		0: 0,
		737: 1.71,
		321: 8.2,
		767: 11.5,
		777: 11.5,
		787: 11.5,
		330: 11.5,
	}

	table757 = {
		0: 8.2,
		200: 8.2,
		300: 11.5,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {757 : (table757, 200)}, table) )

@AlternativeStopPositions
def customOffsetT7Gate76A(aircraftData):

	table = {
		0: 0,
		320: 1.25,
		321: 8.08,
	}

	table737 = {
		0: 1.25,
		800: 1.25,
		900: 2.58,
	}


	table757 = {
		0: 8.08,
		200: 8.08,
		300: 12.24,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
			757 : (table757, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT7Gate77(aircraftData):

	table = {
		0: 0,
		320: 2.55,
		321: 4.8,
		330: 4.8,
		737: 4.8,
		757: 9.81,
	}

	table787 = {
		0: 9.81,
		8: 9.81,
		9: 9.81,
		10: 18.63,
	}

	table777 = {
		0: 18.63,
		200: 14.1,
		300: 18.63,
	}

	table767 = {
		0: 7.52,
		300: 7.52,
		400: 14.1,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			787 : (table787, 0),
			777 : (table777, 0),
			767 : (table767, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetT8Gate80(aircraftData):

	table = {
		0: 0,
		550: 2.05,
		700: 2.05,
		320: 3.75,
		900: 6.65,
		190: 6.65,
		195: 6.65,
	}

	table737 = {
		0: 6.65,
		700: 3.75,
		800: 6.65,
		900: 7.75,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT8Gate81(aircraftData):

	table = {
		0: 0,
		550: 2.78,
		700: 2.78,
		320: 4.63,
		900: 4.63,
		190: 4.63,
		195: 4.63,
	}

	table737 = {
		0: 4.63,
		700: 2.78,
		800: 4.63,
		900: 4.63,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT8Gate82(aircraftData):

	table = {
		0: 0,
		550: 2.45,
		700: 2.45,
		320: 2.45,
		900: 5.18,
		190: 5.18,
		195: 5.18,
	}

	table737 = {
		0: 5.18,
		700: 2.45,
		800: 5.18,
		900: 7.03,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT8Gate83(aircraftData):

	table = {
		0: 0,
		320: 1.87,
		737: 1.87,
		190: 1.87,
		195: 1.87,
		900: 1.87,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetT8Gate84(aircraftData):

	table = {
		0: 0,
		550: 2.22,
		700: 2.22,
		320: 4.43,
		900: 7.94,
		190: 7.94,
		195: 7.94,
	}

	table737 = {
		0: 5.18,
		700: 4.43,
		800: 7.94,
		900: 10.49,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT8Gate85(aircraftData):

	table = {
		0: 0,
		550: 1.52,
		700: 1.52,
		320: 3.53,
		900: 6.91,
		190: 6.91,
		195: 6.91,
	}

	table737 = {
		0: 6.91,
		700: 3.53,
		800: 6.91,
		900: 9.95,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetT8Gate86B(aircraftData):

	table = {
		0: 0,
		550: 2.32,
		700: 2.32,
		320: 2.32,
		900: 4.91,
		190: 4.91,
		195: 4.91,
	}

	table737 = {
		0: 4.91,
		700: 2.32,
		800: 4.91,
		900: 4.91,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, {737 : (table737, 800)}, table) )

@AlternativeStopPositions
def customOffsetGate408(aircraftData):

	table = {
		0: 0,
		330: 11.15,
		767: 11.15,
		757: 11.15,
		777: 14,
		350: 14,
		787: 14,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGate409(aircraftData):

	table = {
		0: 0,
		330: 11.3,
		767: 11.3,
		757: 11.3,
		777: 14.32,
		350: 14.32,
		787: 14.32,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGate412(aircraftData):

	table = {
		0: 0,
		330: 7.1,
		767: 7.1,
		757: 7.1,
		777: 7.1,
		350: 7.1,
		787: 7.1,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGate414(aircraftData):

	table = {
		0: 0,
		330: 6.55,
		767: 6.55,
		757: 6.55,
		777: 12.62,
		350: 12.62,
		787: 12.62,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGate416(aircraftData):

	table = {
		0: 0,
		330: 5.7,
		767: 5.7,
		757: 5.7,
		777: 5.7,
		350: 5.7,
		787: 5.7,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGate418(aircraftData):

	table = {
		0: 0,
		330: 5.98,
		767: 5.98,
		757: 5.98,
		777: 12.16,
		350: 12.16,
		787: 12.16,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

def MyGateNames(name, letter, priority):
	return CustomizedName( "%s|Gate %s#§" % (name, letter), priority )

def MyStandNames(name, letter, priority):
	return CustomizedName( "%s|Bay %s#§" % (name, letter), priority )

TBITNames = MyGateNames("Tom Bradley International Terminal (130-159)", "", 1)
TBITSatelliteNames = MyGateNames("TBIT Satellite Concourse (201-225)", "", 2)
Terminal1Names = MyGateNames("Terminal 1 (9-18)", "", 3)
Terminal2Names = MyGateNames("Terminal 2 (21-28)", "", 4)
Terminal3Names = MyGateNames("Terminal 3 (30-38)", "", 5)
Terminal4Names = MyGateNames("Terminal 4 (40-49)", "", 5)
Terminal5Names = MyGateNames("Terminal 5 (50-59)", "", 6)
Terminal6Names = MyGateNames("Terminal 6 (60-69)", "", 7)
Terminal7Names = MyGateNames("Terminal 7 (70-77)", "", 8)
Terminal8Names = MyGateNames("Terminal 8 (80-86)", "", 9)
RegionalNames = MyGateNames("Regional Terminal (52B-H)", "", 10)
WestRemoteNames = MyGateNames("West Remote Gates (401-419)", "", 11)
CargoNames = MyStandNames("Cargo Ramps", "", 12)
WAMANames = MyStandNames("West Aircraft Maintenance", "", 13)
UALWestNames = MyStandNames("United West Maintenance", "", 14)
UALEastNames = MyStandNames("United East Maintenance", "", 15)
AALNames = MyStandNames("American Airlines Maintenance", "E", 16)
AALSNames = MyStandNames("American Airlines Maintenance", "S", 16)
PrivateJetNames = MyStandNames("Private Jet/GA", "", 17)
OtherNames = MyStandNames("Others", "", 18)

parkings = {
	GATE : {
		None : ( ),
		9 : (Terminal1Names, customOffsetStands1line),
		"11B" : (Terminal1Names, customOffsetT1Gate11B),
		11 : (AALNames, customOffsetStands1line),
		"11A" : (Terminal1Names, customOffsetT1Gate11A),
		"12B" : (Terminal1Names, customOffsetT1Gate12B),
		"12A" : (Terminal1Names, customOffsetT1Gate12A),
		13 : (Terminal1Names, customOffsetT1Gate13),
		14 : (Terminal1Names, customOffsetT1Gate14),
		15 : (Terminal1Names, customOffsetT1Gate15),
		16 : (Terminal1Names, customOffsetT1Gate16),
		"17B" : (Terminal1Names, customOffsetT1Gate17B),
		"17A" : (Terminal1Names, customOffsetT1Gate17A),
		"18B" : (Terminal1Names, customOffsetT1Gate18B),
		"18A" : (Terminal1Names, customOffsetT1Gate18A),
		20 : (Terminal2Names, customOffsetStands1line),
		21 : (Terminal2Names, customOffsetT2Gate21),
		22 : (Terminal2Names, customOffsetT2Gate22),
		"23A" : (Terminal2Names, customOffsetT2Gate23A),
		"23B" : (Terminal2Names, customOffsetT2Gate23B),
		24 : (Terminal2Names, customOffsetT2Gate24),
		25 : (Terminal2Names, customOffsetT2Gate25),
		"25B" : (Terminal2Names, customOffsetT2Gate25B),
		26 : (Terminal2Names, customOffsetT2Gate26),
		"26B" : (Terminal2Names, customOffsetT2Gate26B),
		27 : (Terminal2Names, customOffsetT2Gate27),
		28 : (Terminal2Names, customOffsetT2Gate28),
		30 : (Terminal3Names, customOffsetT3Gate30),
		"30B" : (Terminal3Names, customOffsetT3Gate30B),
		"31A" : (Terminal3Names, customOffsetT3Gate31A),
		"31B" : (Terminal3Names, customOffsetT3Gate31B),
		"32B" : (Terminal3Names, customOffsetT3Gate32B),
		32 : (Terminal3Names, customOffsetT3Gate32),
		33 : (Terminal3Names, customOffsetT3Gate33),
		34 : (Terminal3Names, customOffsetT3Gate34),
		"34B" : (Terminal3Names, customOffsetT3Gate34B),
		35 : (Terminal3Names, customOffsetT3Gate35),
		36 : (Terminal3Names, customOffsetT3Gate36),
		37 : (Terminal3Names, customOffsetT3Gate37),
		"37B" : (Terminal3Names, customOffsetT3Gate37B),
		38 : (Terminal3Names, customOffsetStands1line),
		40 : (Terminal4Names, customOffsetT4Gate40),
		41 : (Terminal4Names, customOffsetT4Gate41),
		"42A" : (Terminal4Names, customOffsetT4Gate42A),
		43 : (Terminal4Names, customOffsetT4Gate43),
		"46C" : (Terminal4Names, customOffsetT4Gate46C),
		"46A" : (Terminal4Names, customOffsetStands1line),
		"47B" : (Terminal4Names, customOffsetT4Gate47B),
		"47A" : (Terminal4Names, customOffsetT4Gate47A),
		"48A" : (Terminal4Names, customOffsetT4Gate48A),
		"48X" : (Terminal4Names, customOffsetT4Gate48X),
		"49A" : (Terminal4Names, customOffsetT4Gate49A),
		"49B" : (Terminal4Names, customOffsetStands1line),
		50 : (Terminal5Names, customOffsetT5Gate50),
		"51B" : (Terminal5Names, customOffsetT5Gate51B),
		"53A" : (Terminal5Names, customOffsetStands1line),
		"53B" : (Terminal5Names, customOffsetT5Gate53B),
		"54A" : (Terminal5Names, customOffsetT5Gate54A),
		"54B" : (Terminal5Names, customOffsetT5Gate54B),
		55 : (Terminal5Names, customOffsetStands1line),
		"56C" : (Terminal5Names, customOffsetStands1line),
		"56B" : (Terminal5Names, customOffsetT5Gate56B),
		"56A" : (Terminal5Names, customOffsetT5Gate56A),
		57 : (Terminal5Names, customOffsetT5Gate57),
		58 : (Terminal5Names, customOffsetStands1line),
		59 : (Terminal5Names, customOffsetT5Gate59),
		60 : (Terminal6Names, customOffsetT6Gate60),
		61 : (Terminal6Names, customOffsetStands1line),
		62 : (Terminal6Names, customOffsetT6Gate62),
		64 : (Terminal6Names, customOffsetT6Gate64),
		"65B" : (Terminal6Names, customOffsetT6Gate65B),
		"65C" : (Terminal6Names, customOffsetT6Gate65C),
		"65A" : (Terminal6Names, customOffsetStands1line),
		66 : (Terminal6Names, customOffsetT6Gate66),
		67 : (Terminal6Names, customOffsetT6Gate67),
		"68A" : (Terminal6Names, customOffsetStands1line),
		"68B" : (Terminal6Names, customOffsetT6Gate68B),
		"69B" : (Terminal6Names, customOffsetStands1line),
		"69A" : (Terminal6Names, customOffsetStands1line),
		"70A" : (Terminal7Names, customOffsetT7Gate70A),
		"70B" : (Terminal7Names, customOffsetT7Gate70B),
		"71B" : (Terminal7Names, customOffsetT7Gate71B),
		"71A" : (Terminal7Names, customOffsetT7Gate71A),
		"72A" : (CustomizedName("Terminal 7 (70-77)|Gate 72W", 8), customOffsetT7Gate72W),
		"72B" : (Terminal7Names, customOffsetT7Gate72B),
		73 : (Terminal7Names, customOffsetT7Gate73),
		74 : (Terminal7Names, customOffsetT7Gate74),
		"75B" : (Terminal7Names, customOffsetT7Gate75B),
		"75A" : (Terminal7Names, customOffsetT7Gate75A),
		76 : (Terminal7Names, customOffsetT7Gate76A),
		"76B" : (Terminal7Names, customOffsetStands1line),
		77 : (Terminal7Names, customOffsetT7Gate77),
		80 : (Terminal8Names, customOffsetT8Gate80),
		81 : (Terminal8Names, customOffsetT8Gate81),
		82 : (Terminal8Names, customOffsetT8Gate82),
		83 : (Terminal8Names, customOffsetT8Gate83),
		84 : (Terminal8Names, customOffsetT8Gate84),
		85 : (Terminal8Names, customOffsetT8Gate85),
		"86A" : (Terminal8Names, customOffsetStands1line),
		"86B" : (Terminal8Names, customOffsetT8Gate86B),
		130 : (TBITNames, customOffsetTBITGate130),
		131 : (TBITNames, customOffsetTBITGate131),
		132 : (TBITNames, customOffsetTBITGate132),
		133 : (TBITNames, customOffsetTBITGate133),
		134 : (TBITNames, customOffsetTBITGate134),
		135 : (TBITNames, customOffsetStands1line),
		137 : (TBITNames, customOffsetTBITGate137),
		139 : (TBITNames, customOffsetTBITGate139),
		141 : (TBITNames, customOffsetTBITGate141),
		148 : (TBITNames, customOffsetTBITGate148),
		150 : (TBITNames, customOffsetTBITGate150),
		151 : (TBITNames, customOffsetTBITGate151),
		152 : (TBITNames, customOffsetTBITGate152),
		153 : (TBITNames, customOffsetTBITGate153),
		154 : (TBITNames, customOffsetTBITGate154),
		155 : (TBITNames, customOffsetTBITGate155),
		156 : (TBITNames, customOffsetTBITGate156),
		157 : (TBITNames, customOffsetTBITGate157),
		159 : (TBITNames, customOffsetTBITGate159),
		"201A" : (TBITSatelliteNames, customOffsetTBITGate201A),
		"201B" : (TBITSatelliteNames, customOffsetTBITGate201B),
		202 : (TBITSatelliteNames, customOffsetTBITGate202),
		203 : (TBITSatelliteNames, customOffsetTBITGate203),
		204 : (TBITSatelliteNames, customOffsetTBITGate204),
		205 : (TBITSatelliteNames, customOffsetTBITGate205),
		206 : (TBITSatelliteNames, customOffsetTBITGate206),
		207 : (TBITSatelliteNames, customOffsetTBITGate207),
		208 : (TBITSatelliteNames, customOffsetTBITGate208),
		209 : (TBITSatelliteNames, customOffsetTBITGate209),
		"210A" : (TBITSatelliteNames, customOffsetTBITGate210A),
		"210B" : (TBITSatelliteNames, customOffsetTBITGate210B),
		221 : (TBITSatelliteNames, customOffsetTBITGate221),
		225 : (TBITSatelliteNames, customOffsetTBITGate225),
		254 : (CustomizedName("Others|Bay X1", 18), ),
		406 : (WestRemoteNames, customOffsetStands1line),
		407 : (WestRemoteNames, customOffsetStands1line),
		408 : (WestRemoteNames, customOffsetGate408),
		409 : (WestRemoteNames, customOffsetGate409),
		410 : (WestRemoteNames, customOffsetStands1line),
		412 : (WestRemoteNames, customOffsetGate412),
		414 : (WestRemoteNames, customOffsetGate414),
		416 : (WestRemoteNames, customOffsetGate416),
		418 : (WestRemoteNames, customOffsetGate418),
		419 : (WestRemoteNames, customOffsetStands1line),
	},
	GATE_A : {
		None : ( ),
		"42B" : (Terminal4Names, customOffsetT4Gate42B),
	},
	GATE_B : {
		None : ( ),
		45 : (Terminal4Names, customOffsetT4Gate45),
		"46B" : (Terminal4Names, customOffsetT4Gate46B),
	},
	GATE_E : {
		None : (AALNames, customOffsetStands1line),
	},
	GATE_S : {
		None : (AALSNames, customOffsetStands1line),
	},
	GATE_Z : {
		None : ( ),
		"52B" : (CustomizedName("Regional Terminal|Gate 52C", 10), customOffsetStands1line),
		"52C" : (CustomizedName("Regional Terminal|Gate 52D", 10), customOffsetStands1line),
		"52D" : (CustomizedName("Regional Terminal|Gate 52E", 10), customOffsetStands1line),
		"52E" : (CustomizedName("Regional Terminal|Gate 52F", 10), customOffsetStands1line),
		"52F" : (CustomizedName("Regional Terminal|Gate 52G", 10), customOffsetStands1line),
		"52G" : (CustomizedName("Regional Terminal|Gate 52H", 10), customOffsetStands1line),
		"52H" : (CustomizedName("Regional Terminal|Gate 52I", 10), customOffsetStands1line),
	},
	NW_PARKING : {
		None : ( ),
		1 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		2 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		3 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		4 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		5 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		6 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		7 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		8 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		9 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
		10 : (CustomizedName("Cargo Ramps|Imperial Cargo Complex - Bay #", 12), customOffsetStands1line),
	},
	NE_PARKING : {
		None : ( ),
		"1A" : (CustomizedName("Cargo Ramps|B-1 Cargo Area - Bay 933", 12), customOffsetStands1line),
		"1B" : (CustomizedName("Cargo Ramps|B-1 Cargo Area - Bay 933B", 12), customOffsetStands1line),
		"2A" : (CustomizedName("Cargo Ramps|B-1 Cargo Area - Bay 932B", 12), customOffsetStands1line),
		"2C" : (CustomizedName("Cargo Ramps|B-1 Cargo Area - Bay 931B", 12), customOffsetStands1line),
		"2D" : (CustomizedName("Cargo Ramps|B-1 Cargo Area - Bay 931", 12), customOffsetStands1line),
		"2B" : (CustomizedName("Cargo Ramps|B-1 Cargo Area - Bay 932", 12), customOffsetStands1line),
		941 : (CustomizedName("Cargo Ramps|C-1 Cargo Area - Bay #", 12), customOffsetStands1line),
		943 : (CustomizedName("Cargo Ramps|C-1 Cargo Area - Bay #", 12), customOffsetStands1line),
	},
	PARKING : {
		None : ( ),
		1 : (OtherNames, customOffsetStands1line),
		2 : (OtherNames, customOffsetStands1line),
		3 : (OtherNames, customOffsetStands1line),
		4 : (OtherNames, customOffsetStands1line),
		6 : (OtherNames, customOffsetStands1line),
		7 : (OtherNames, customOffsetStands1line),
		100 : (WAMANames, customOffsetStands1line),
		101 : (WAMANames, customOffsetStands1line),
		103 : (WAMANames, customOffsetStands1line),
		106 : (WAMANames, customOffsetStands1line),
		107 : (WAMANames, customOffsetStands1line),
		108 : (WAMANames, customOffsetStands1line),
		110 : (WAMANames, customOffsetStands1line),
		111 : (WAMANames, customOffsetStands1line),
		112 : (WAMANames, customOffsetStands1line),
		113 : (WAMANames, customOffsetStands1line),
		275 : (CustomizedName("United East Maintenance|Bay 13", 15), customOffsetStands1line),
		276 : (CustomizedName("United East Maintenance|Bay 12", 15), customOffsetStands1line),
		277 : (CustomizedName("United East Maintenance|Bay 11", 15), customOffsetStands1line),
		280 : (CustomizedName("United East Maintenance|Bay 10", 15),customOffsetStands1line ),
		290 : (CustomizedName("Cargo Ramps|C1 Parking - Bay 941", 12), customOffsetStands1line),
		291 : (CustomizedName("Cargo Ramps|C1 Parking - Bay 943", 12), customOffsetStands1line),
		302 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 8", 12), customOffsetStands1line),
		303 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 9", 12), customOffsetStands1line),
		304 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 7", 12), customOffsetStands1line),
		305 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 6", 12), customOffsetStands1line),
		306 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 5", 12), customOffsetStands1line),
		307 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 4", 12), customOffsetStands1line),
		308 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 3", 12), customOffsetStands1line),
		309 : (CustomizedName("Cargo Ramps|FedEx Ramp - Bay 2", 12), customOffsetStands1line),
		310 : (CustomizedName("Cargo Ramps|Japan Airlines Cargo - Bay 2", 12), customOffsetStands1line),
		311 : (CustomizedName("Cargo Ramps|Japan Airlines Cargo - Bay 1", 12), customOffsetStands1line),
		312 : (CustomizedName("Cargo Ramps|Korean Airlines Cargo - Bay KAL1", 12), customOffsetStands1line),
		313 : (CustomizedName("Cargo Ramps|Korean Airlines Cargo - Bay KAL2", 12), customOffsetStands1line),
		319 : (CustomizedName("Cargo Ramps|South Pads - Bay B", 12), customOffsetStands1line),
		320 : (CustomizedName("Cargo Ramps|South Pads - Bay C", 12), customOffsetStands1line),
		321 : (CustomizedName("United West Maintenance|Bay 12", 12), customOffsetStands1line),
		322 : (CustomizedName("United West Maintenance|Bay 13", 12), customOffsetStands1line),
		323 : (CustomizedName("United West Maintenance|Bay 15", 12), customOffsetStands1line),
		325 : (CustomizedName("United West Maintenance|Bay 16", 12), customOffsetStands1line),
		326 : (CustomizedName("United West Maintenance|Bay 10", 12), customOffsetStands1line),
		327 : (CustomizedName("United West Maintenance|Bay 8", 12), customOffsetStands1line),
		328 : (CustomizedName("United West Maintenance|Bay 9", 12), customOffsetStands1line),
		329 : (CustomizedName("United West Maintenance|Bay 11", 12), customOffsetStands1line),
		330 : (CustomizedName("United West Maintenance|Bay 3", 12), customOffsetStands1line),
		331 : (CustomizedName("United West Maintenance|Bay 4", 12), customOffsetStands1line),
		332 : (CustomizedName("United West Maintenance|Bay 5", 12), customOffsetStands1line),
		333 : (CustomizedName("United West Maintenance|Bay 6", 12), customOffsetStands1line),
		334 : (CustomizedName("United West Maintenance|Bay 7", 12), customOffsetStands1line),
		376 : (CustomizedName("Private Jet/GA|Atlantic FBO", 12), customOffsetStands1line),
		381 : (CustomizedName("Private Jet/GA|Signature FBO", 12), customOffsetStands1line),
		382 : (CustomizedName("Cargo Ramps|Singapore Airlines Cargo - Bay SIA1", 12), customOffsetStands1line),
		383 : (CustomizedName("Private Jet/GA|Signature FBO", 12), customOffsetStands1line),
		403 : (WestRemoteNames, customOffsetStands1line),
		411 : (WestRemoteNames, customOffsetStands1line),
		413 : (WestRemoteNames, customOffsetStands1line),
		415 : (WestRemoteNames, customOffsetStands1line),
		417 : (WestRemoteNames, customOffsetStands1line),
		502 : (WAMANames, customOffsetStands1line),
	},
	0 : {
		None : ( ),
		102 : (WAMANames, customOffsetStands1line),
		"401A" : (WestRemoteNames, customOffsetStands1line),
		"401B" : (WestRemoteNames, customOffsetStands1line),
		"401C" : (WestRemoteNames, customOffsetStands1line),
		"402A" : (WestRemoteNames, customOffsetStands1line),
		"402B" : (WestRemoteNames, customOffsetStands1line),
		"402C" : (WestRemoteNames, customOffsetStands1line),
		"402D" : (WestRemoteNames, customOffsetStands1line),
		"402E" : (WestRemoteNames, customOffsetStands1line),
		"405A" : (WestRemoteNames, customOffsetStands1line),
		"405B" : (WestRemoteNames, customOffsetStands1line),
		"405C" : (WestRemoteNames, customOffsetStands1line),
		"942B" : (CustomizedName("Cargo Ramps|C-1 Cargo Area - Bay 942B", 12), customOffsetStands1line),
		"942A" : (CustomizedName("Cargo Ramps|C-1 Cargo Area - Bay 942A", 12), customOffsetStands1line),
		944 : (CustomizedName("Cargo Ramps|C-1 Cargo Area - Bay #", 12), customOffsetStands1line),
		946 : (CustomizedName("Cargo Ramps|C-1 Cargo Area - Bay #", 12), customOffsetStands1line),
	},
	S_PARKING : {
		None : ( ),
		1 : (CustomizedName("Cargo Ramps|South Pads - Bay #", 12), customOffsetStands1line),
		2 : (CustomizedName("Cargo Ramps|South Pads - Bay #", 12), customOffsetStands1line),
		3 : (CustomizedName("Cargo Ramps|South Pads - Bay #", 12), customOffsetStands1line),
		4 : (CustomizedName("Cargo Ramps|South Pads - Bay #", 12), customOffsetStands1line),
		5 : (CustomizedName("Cargo Ramps|South Pads - Bay #", 12), customOffsetStands1line),
	},
}