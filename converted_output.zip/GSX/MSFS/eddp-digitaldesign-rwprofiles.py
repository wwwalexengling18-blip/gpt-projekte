# -- coding: utf-8 --

msfs_mode = 1
icao = "eddp"
			
def HandleAircraftOffsets(aircraftData, specificTables, genericTable):
	try:
		return specificTables[aircraftData.idMajor][0].get(aircraftData.idMinor)
	except:
		try:
			return specificTables[aircraftData.idMajor][0].get(specificTables[aircraftData.idMajor][1])
		except:
			return genericTable.get(aircraftData.idMajor, 0)

@AlternativeStopPositions
def customOffset1stopLine(aircraftData):
	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetTerminal(aircraftData):
	table = {
		0: 0,
		737: 2.05,
		319: 2.05,
		320: 2.05,
		321: 2.05,
		170: 0,
		175: 0,
		190: 2.05,
		195: 2.05,
		221: 2.05,
		223: 2.05,
		700: 0,
		900: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffset4stopsApron4(aircraftData):
	table = {
		0: 0,
		737: 0,
		757: 7.0,
		767: 10.55,
		777: 10.55,
		300: 3.1,
		310: 3.1,
		321: 7.0,
		330: 10.55,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetStand422(aircraftData):
	table = {
		0: 0,
		737: 2.75,
		757: 10.65,
		767: 10.65,
		777: 10.65,
		300: 10.65,
		310: 10.65,
		321: 2.75,
		330: 10.65,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffset3stopsApron4(aircraftData):
	table = {
		0: 0,
		737: 2.35,
		757: 9.25,
		767: 9.25,
		777: 9.25,
		300: 9.25,
		310: 9.25,
		321: 2.35,
		330: 9.25,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffset3stopsType2Apron4(aircraftData):
	table = {
		0: 0,
		737: 0,
		757: 7.6,
		767: 7.6,
		777: 7.6,
		300: 3.9,
		310: 3.9,
		321: 3.9,
		330: 7.6,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetHeavyApron4(aircraftData):
	table = {
		0: 0,
		737: 16.5,
		757: 16.5,
		767: 16.5,
		747: 16.5,
		777: 16.5,
		300: 16.5,
		310: 16.5,
		321: 16.5,
		330: 16.5,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

@AlternativeStopPositions
def customOffsetLRApron4(aircraftData):
	table = {
		0: 0,
		737: 4.87,
		757: 4.87,
		321: 4.87,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

def MyStandNames(name, letter, priority):
	return CustomizedName( "%s|Stand %s#§" % (name, letter), priority )

Apron1TerminalNames = MyStandNames("Apron 1 - Terminal (126-136)", "", 1)
Apron1RemoteNames = MyStandNames("Apron 1 - Remotes (101-120 + 137-143)", "", 2)
Apron2Names = MyStandNames("Apron 2 (201-222)", "", 3)
Apron3Names = MyStandNames("Apron 3 (306-307)", "", 4)
Apron4Names = MyStandNames("Apron 4 (401-487)", "", 5)
Apron5Names = MyStandNames("Apron 5 (501-506)", "", 6)

parkings = {
	GATE : {
		None : ( ),
				126 : (Apron1TerminalNames, customOffsetTerminal),
				128 : (Apron1TerminalNames, customOffsetTerminal),
				130 : (Apron1TerminalNames, customOffsetTerminal),
				132 : (Apron1TerminalNames, customOffsetTerminal),
				134 : (Apron1TerminalNames, customOffsetTerminal),
				136 : (Apron1TerminalNames, customOffsetTerminal),
	},
	N_PARKING : {
		None : ( ),
				307 : (Apron3Names, customOffset1stopLine),
				306 : (Apron3Names, customOffset1stopLine),
	},
	PARKING: {
		None : ( ),
				101 : (Apron1RemoteNames, customOffset1stopLine),
				102 : (Apron1RemoteNames, customOffset1stopLine),
				103 : (Apron1RemoteNames, customOffset1stopLine),
				104 : (Apron1RemoteNames, customOffset1stopLine),
				106 : (Apron1RemoteNames, customOffset1stopLine),
				107 : (Apron1RemoteNames, customOffset1stopLine),
				108 : (Apron1RemoteNames, customOffset1stopLine),
				110 : (Apron1RemoteNames, customOffset1stopLine),
				111 : (Apron1RemoteNames, customOffset1stopLine),
				115 : (Apron1RemoteNames, customOffset1stopLine),
				118 : (Apron1RemoteNames, customOffset1stopLine),
				120 : (Apron1RemoteNames, customOffset1stopLine),
				137 : (Apron1RemoteNames, customOffset1stopLine),
				140 : (Apron1RemoteNames, customOffset1stopLine),
				142 : (Apron1RemoteNames, customOffset1stopLine),
				143 : (Apron1RemoteNames, customOffset1stopLine),
	},
	0 : {
		None : ( ),
				"481R" : (Apron4Names, customOffsetLRApron4),
	},
	S_PARKING : {
		None : ( ),
				401 : (Apron4Names, customOffset4stopsApron4),
				402 : (Apron4Names, customOffset4stopsApron4),
				403 : (Apron4Names, customOffset4stopsApron4),
				404 : (Apron4Names, customOffset4stopsApron4),
				405 : (Apron4Names, customOffset4stopsApron4),
				406 : (Apron4Names, customOffset4stopsApron4),
				407 : (Apron4Names, customOffset4stopsApron4),
				408 : (Apron4Names, customOffset4stopsApron4),
				409 : (Apron4Names, customOffset4stopsApron4),
				410 : (Apron4Names, customOffset4stopsApron4),
				411 : (Apron4Names, customOffset4stopsApron4),
				412 : (Apron4Names, customOffset4stopsApron4),
				421 : (Apron4Names, customOffset3stopsApron4),
				422 : (Apron4Names, customOffsetStand422),
				424 : (Apron4Names, customOffset3stopsApron4),
				425 : (Apron4Names, customOffset3stopsApron4),
				426 : (Apron4Names, customOffset3stopsApron4),
				427 : (Apron4Names, customOffset3stopsApron4),
				428 : (Apron4Names, customOffset3stopsApron4),
				429 : (Apron4Names, customOffset3stopsApron4),
				430 : (Apron4Names, customOffset3stopsApron4),
				431 : (Apron4Names, customOffset3stopsApron4),
				432 : (Apron4Names, customOffset3stopsApron4),
				433 : (Apron4Names, customOffset3stopsApron4),
				434 : (Apron4Names, customOffset3stopsApron4),
				435 : (Apron4Names, customOffset3stopsApron4),
				436 : (Apron4Names, customOffset3stopsApron4),
				441 : (Apron4Names, customOffset4stopsApron4),
				442 : (Apron4Names, customOffset4stopsApron4),
				443 : (Apron4Names, customOffset4stopsApron4),
				444 : (Apron4Names, customOffset4stopsApron4),
				445 : (Apron4Names, customOffset4stopsApron4),
				446 : (Apron4Names, customOffset4stopsApron4),
				447 : (Apron4Names, customOffset4stopsApron4),
				448 : (Apron4Names, customOffset4stopsApron4),
				449 : (Apron4Names, customOffset4stopsApron4),
				450 : (Apron4Names, customOffset4stopsApron4),
				451 : (Apron4Names, customOffset4stopsApron4),
				452 : (Apron4Names, customOffset4stopsApron4),
				461 : (Apron4Names, customOffset3stopsType2Apron4),
				462 : (Apron4Names, customOffset3stopsType2Apron4),
				463 : (Apron4Names, customOffset1stopLine),
				464 : (Apron4Names, customOffset1stopLine),
				465 : (Apron4Names, customOffset3stopsType2Apron4),
				466 : (Apron4Names, customOffset3stopsType2Apron4),
				467 : (Apron4Names, customOffset3stopsType2Apron4),
				468 : (Apron4Names, customOffset3stopsType2Apron4),
				469 : (Apron4Names, customOffset1stopLine),
				470 : (Apron4Names, customOffset1stopLine),
				471 : (Apron4Names, customOffset3stopsType2Apron4),
				472 : (Apron4Names, customOffset3stopsType2Apron4),
				473 : (Apron4Names, customOffset3stopsType2Apron4),
				474 : (Apron4Names, customOffset3stopsType2Apron4),
				475 : (Apron4Names, customOffset1stopLine),
				476 : (Apron4Names, customOffset1stopLine),
				477 : (Apron4Names, customOffset3stopsType2Apron4),
				478 : (Apron4Names, customOffset3stopsType2Apron4),
				"481L" : (Apron4Names, customOffsetLRApron4),
				481 : (Apron4Names, customOffsetHeavyApron4),
				"483R" : (Apron4Names, customOffsetLRApron4),
				"483L" : (Apron4Names, customOffsetLRApron4),
				483 : (Apron4Names, customOffsetHeavyApron4),
				"485R" : (Apron4Names, customOffsetLRApron4),
				"485L" : (Apron4Names, customOffsetLRApron4),
				485 : (Apron4Names, customOffsetHeavyApron4),
				"487R" : (Apron4Names, customOffsetLRApron4),
				"487L" : (Apron4Names, customOffsetLRApron4),
				487 : (Apron4Names, customOffsetHeavyApron4),
				501 : (Apron5Names, customOffset1stopLine),
				503 : (Apron5Names, customOffset1stopLine),
				504 : (Apron5Names, customOffset1stopLine),
				506 : (Apron5Names, customOffset1stopLine),
	},
	SW_PARKING: {
		None : ( ),
				201 : (Apron2Names, customOffset1stopLine),
				203 : (Apron2Names, customOffset1stopLine),
				205 : (Apron2Names, customOffset1stopLine),
				207 : (Apron2Names, customOffset1stopLine),
				209 : (Apron2Names, customOffset1stopLine),
				211 : (Apron2Names, customOffset1stopLine),
				215 : (Apron2Names, customOffset1stopLine),
				216 : (Apron2Names, customOffset1stopLine),
				217 : (Apron2Names, customOffset1stopLine),
				220 : (Apron2Names, customOffset1stopLine),
				221 : (Apron2Names, customOffset1stopLine),
				222 : (Apron2Names, customOffset1stopLine),
	},
}