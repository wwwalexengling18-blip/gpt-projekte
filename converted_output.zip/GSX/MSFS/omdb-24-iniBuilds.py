# -- coding: utf-8 --

msfs_mode = 1
icao = "omdb"
			
def HandleAircraftOffsets(aircraftData, specificTables, genericTable):
	try:
		return specificTables[aircraftData.idMajor][0].get(aircraftData.idMinor)
	except:
		try:
			return specificTables[aircraftData.idMajor][0].get(specificTables[aircraftData.idMajor][1])
		except:
			return genericTable.get(aircraftData.idMajor, 0)

@AlternativeStopPositions
def customOffsetStands1line(aircraftData):

	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGateA2(aircraftData):

	table = {
		0: 0,
		380: 7,
	}

	table777 = {
		0: 9.82,
		200: 4.14,
		300: 9.82,
	}

	table340 = {
		0: 1.48,
		200: 1.48,
		300: 1.48,
		500: 4.14,
		600: 4.14,
	}

	table350 = {
		0: 2.68,
		900: 2.68,
		1000: 9.82,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA3(aircraftData):

	table = {
		0: 0,
		380: 7.66,
	}

	table777 = {
		0: 9.99,
		200: 4.14,
		300: 9.99,
	}

	table340 = {
		0: 1.48,
		200: 1.48,
		300: 1.48,
		500: 4.14,
		600: 4.14,
	}

	table350 = {
		0: 2.68,
		900: 2.68,
		1000: 9.99,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA4(aircraftData):

	table = {
		0: 0,
		380: 7.65,
	}

	table777 = {
		0: 9.95,
		200: 4.11,
		300: 9.95,
	}

	table340 = {
		0: 1.44,
		200: 1.44,
		300: 1.44,
		500: 4.11,
		600: 4.11,
	}

	table350 = {
		0: 4.11,
		900: 4.11,
		1000: 9.95,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA5(aircraftData):

	table = {
		0: 0,
		380: 7.52,
	}

	table777 = {
		0: 9.86,
		200: 4.14,
		300: 9.86,
	}

	table340 = {
		0: 1.43,
		200: 1.43,
		300: 1.43,
		500: 4.14,
		600: 4.14,
	}

	table350 = {
		0: 2.8,
		900: 2.8,
		1000: 9.86,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA6(aircraftData):

	table = {
		0: 0,
		380: 7.52,
	}

	table777 = {
		0: 9.86,
		200: 4.15,
		300: 9.86,
	}

	table340 = {
		0: 1.4,
		200: 1.4,
		300: 1.4,
		500: 4.15,
		600: 4.15,
	}

	table350 = {
		0: 2.7,
		900: 2.7,
		1000: 9.86,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA8(aircraftData):

	table = {
		0: 0,
		380: 7.54,
	}

	table777 = {
		0: 9.87,
		200: 4.18,
		300: 9.87,
	}

	table340 = {
		0: 1.43,
		200: 1.43,
		300: 1.43,
		500: 4.18,
		600: 4.18,
	}

	table350 = {
		0: 2.72,
		900: 2.72,
		1000: 9.87,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA9(aircraftData):

	table = {
		0: 0,
		380: 7.55,
	}

	table777 = {
		0: 9.88,
		200: 4.12,
		300: 9.88,
	}

	table340 = {
		0: 1.45,
		200: 1.45,
		300: 1.45,
		500: 4.12,
		600: 4.12,
	}

	table350 = {
		0: 2.78,
		900: 2.78,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateA10(aircraftData):

	table = {
		0: 0,
		380: 7.48,
	}

	table777 = {
		0: 9.8,
		200: 4.1,
		300: 9.8,
	}

	table340 = {
		0: 1.45,
		200: 1.45,
		300: 1.45,
		500: 4.1,
		600: 4.1,
	}

	table350 = {
		0: 2.78,
		900: 2.78,
		1000: 9.8,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB1(aircraftData):

	table = {
		0: 0,
		380: 13.7,
	}

	table777 = {
		0: 11.35,
		200: 6.53,
		300: 11.35,
	}

	table350 = {
		0: 11.35,
		900: 11.35,
		1000: 13.7,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB2B3B4B6(aircraftData):

	table = {
		0: 0,
		380: 13.65,
	}

	table777 = {
		0: 11.32,
		200: 6.51,
		300: 11.32,
	}

	table350 = {
		0: 11.32,
		900: 11.32,
		1000: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB8B9B10(aircraftData):

	table = {
		0: 0,
		380: 7.58,
	}

	table777 = {
		0: 9.9,
		200: 4.18,
		300: 9.9,
	}

	table340 = {
		0: 1.43,
		200: 1.43,
		300: 1.43,
		500: 4.18,
		600: 4.18,
	}

	table350 = {
		0: 2.75,
		900: 2.75,
		1000: 9.9,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB11(aircraftData):

	table = {
		0: 0,
		380: 7.55,
	}

	table777 = {
		0: 9.89,
		200: 4.14,
		300: 9.89,
	}

	table340 = {
		0: 1.42,
		200: 1.42,
		300: 1.42,
		500: 4.14,
		600: 4.14,
	}

	table350 = {
		0: 2.82,
		900: 2.82,
		1000: 9.89,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB14(aircraftData):

	table = {
		0: 0,
		787: 6.53,
		380: 13.67,
	}

	table777 = {
		0: 11.32,
		200: 6.53,
		300: 11.32,
	}

	table350 = {
		0: 11.32,
		900: 11.32,
		1000: 13.67,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB15B20B21B22B23B24B25(aircraftData):

	table = {
		0: 0,
		380: 13.68,
		787: 6.51,
	}

	table777 = {
		0: 11.33,
		200: 6.51,
		300: 11.33,
	}

	table350 = {
		0: 11.33,
		900: 11.33,
		1000: 13.68,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB16(aircraftData):

	table = {
		0: 0,
		787: 6.51,
		380: 13.65,
	}

	table777 = {
		0: 11.32,
		200: 6.51,
		300: 11.32,
	}

	table350 = {
		0: 11.32,
		900: 11.32,
		1000: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateB27(aircraftData):

	table = {
		0: 0,
		380: 7.51,
	}

	table777 = {
		0: 9.86,
		200: 4.14,
		300: 9.86,
	}

	table340 = {
		0: 1.4,
		200: 1.4,
		300: 1.4,
		500: 4.14,
		600: 4.14,
	}

	table350 = {
		0: 2.68,
		900: 2.68,
		1000: 9.86,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC18C19C20C21C22C23(aircraftData):

	table = {
		0: 0,
		319: 6.98,
		320: 6.98,
		321: 6.98,
		170: 6.98,
		175: 6.98,
		190: 6.98,
		195: 6.98,
		737: 10.25,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGateC24C25C26C27(aircraftData):

	table = {
		0: 0,
		777: 3.72,
		319: 6.98,
		320: 6.98,
		321: 6.98,
		170: 6.98,
		175: 6.98,
		190: 6.98,
		195: 6.98,
		737: 10.25,
		350: 10.25,
		380: 10.25,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGateC28(aircraftData):

	table = {
		0: 0,
		310: 2.14,
		747: 20,
		380: 20,
	}

	table777 = {
		0: 16.68,
		200: 9.75,
		300: 16.68,
	}

	table787 = {
		0: 16.68,
		8: 9.75,
		9: 13.44,
		10: 16.68,
	}

	table330 = {
		0: 13.44,
		200: 9.75,
		800: 9.75,
		300: 13.44,
		900: 13.44,
	}

	table340 = {
		0: 13.44,
		200: 13.44,
		300: 13.44,
		500: 20,
		600: 20,
	}

	table350 = {
		0: 16.68,
		900: 16.68,
		1000: 20,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC29(aircraftData):

	table = {
		0: 0,
		310: 2.14,
		747: 19.87,
		380: 19.87,
	}

	table777 = {
		0: 16.58,
		200: 9.61,
		300: 16.58,
	}

	table787 = {
		0: 16.58,
		8: 9.61,
		9: 13.32,
		10: 16.58,
	}

	table330 = {
		0: 13.32,
		200: 9.61,
		800: 9.61,
		300: 13.32,
		900: 13.32,
	}

	table340 = {
		0: 13.32,
		200: 13.32,
		300: 13.32,
		500: 19.87,
		600: 19.87,
	}

	table350 = {
		0: 16.58,
		900: 16.58,
		1000: 19.87,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC30(aircraftData):

	table = {
		0: 0,
		310: 2.14,
		747: 19.99,
		380: 19.99,
	}

	table777 = {
		0: 16.68,
		200: 9.7,
		300: 16.68,
	}

	table787 = {
		0: 16.68,
		8: 9.7,
		9: 13.44,
		10: 16.68,
	}

	table330 = {
		0: 13.44,
		200: 9.7,
		800: 9.7,
		300: 13.44,
		900: 13.44,
	}

	table340 = {
		0: 13.44,
		200: 13.44,
		300: 13.44,
		500: 19.99,
		600: 19.99,
	}

	table350 = {
		0: 16.68,
		900: 16.68,
		1000: 19.99,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC31(aircraftData):

	table = {
		0: 0,
		310: 2.28,
		747: 19.5,
		380: 19.5,
	}

	table777 = {
		0: 16.61,
		200: 9.62,
		300: 16.61,
	}

	table787 = {
		0: 16.61,
		8: 9.62,
		9: 14.21,
		10: 16.61,
	}

	table330 = {
		0: 14.21,
		200: 9.62,
		800: 9.62,
		300: 14.21,
		900: 14.21,
	}

	table340 = {
		0: 14.21,
		200: 14.21,
		300: 14.21,
		500: 19.5,
		600: 19.5,
	}

	table350 = {
		0: 16.61,
		900: 16.61,
		1000: 19.5,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC32(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.47,
		380: 19.47,
	}

	table777 = {
		0: 16.61,
		200: 9.65,
		300: 16.61,
	}

	table787 = {
		0: 16.61,
		8: 9.65,
		9: 14.17,
		10: 16.61,
	}

	table330 = {
		0: 14.17,
		200: 9.65,
		800: 9.65,
		300: 14.17,
		900: 14.17,
	}

	table340 = {
		0: 14.17,
		200: 14.17,
		300: 14.17,
		500: 19.47,
		600: 19.47,
	}

	table350 = {
		0: 16.61,
		900: 16.61,
		1000: 19.47,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC34(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.52,
		380: 19.52,
	}

	table777 = {
		0: 16.65,
		200: 9.63,
		300: 16.65,
	}

	table787 = {
		0: 16.65,
		8: 9.63,
		9: 14.22,
		10: 16.65,
	}

	table330 = {
		0: 14.22,
		200: 9.63,
		800: 9.63,
		300: 14.22,
		900: 14.22,
	}

	table340 = {
		0: 14.22,
		200: 14.22,
		300: 14.22,
		500: 19.52,
		600: 19.52,
	}

	table350 = {
		0: 16.65,
		900: 16.65,
		1000: 19.52,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC35(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.52,
		380: 19.52,
	}

	table777 = {
		0: 16.63,
		200: 9.65,
		300: 16.63,
	}

	table787 = {
		0: 16.63,
		8: 9.65,
		9: 14.22,
		10: 16.63,
	}

	table330 = {
		0: 14.22,
		200: 9.65,
		800: 9.65,
		300: 14.22,
		900: 14.22,
	}

	table340 = {
		0: 14.22,
		200: 14.22,
		300: 14.22,
		500: 19.52,
		600: 19.52,
	}

	table350 = {
		0: 16.63,
		900: 16.63,
		1000: 19.52,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC36(aircraftData):

	table = {
		0: 0,
		310: 2.2,
		747: 19.52,
		380: 19.52,
	}

	table777 = {
		0: 16.65,
		200: 9.67,
		300: 16.65,
	}

	table787 = {
		0: 16.65,
		8: 9.67,
		9: 14.22,
		10: 16.65,
	}

	table330 = {
		0: 14.22,
		200: 9.67,
		800: 9.67,
		300: 14.22,
		900: 14.22,
	}

	table340 = {
		0: 14.22,
		200: 14.22,
		300: 14.22,
		500: 19.52,
		600: 19.52,
	}

	table350 = {
		0: 16.65,
		900: 16.65,
		1000: 19.52,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC37(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.49,
		380: 19.49,
	}

	table777 = {
		0: 16.63,
		200: 9.62,
		300: 16.63,
	}

	table787 = {
		0: 16.63,
		8: 9.62,
		9: 14.2,
		10: 16.63,
	}

	table330 = {
		0: 14.2,
		200: 9.62,
		800: 9.62,
		300: 14.2,
		900: 14.2,
	}

	table340 = {
		0: 14.2,
		200: 14.2,
		300: 14.2,
		500: 19.49,
		600: 19.49,
	}

	table350 = {
		0: 16.63,
		900: 16.63,
		1000: 19.49,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC38(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.51,
		380: 19.51,
	}

	table777 = {
		0: 16.63,
		200: 9.65,
		300: 16.63,
	}

	table787 = {
		0: 16.63,
		8: 9.65,
		9: 14.2,
		10: 16.63,
	}

	table330 = {
		0: 14.2,
		200: 9.65,
		800: 9.65,
		300: 14.2,
		900: 14.2,
	}

	table340 = {
		0: 14.2,
		200: 14.2,
		300: 14.2,
		500: 19.51,
		600: 19.51,
	}

	table350 = {
		0: 16.63,
		900: 16.63,
		1000: 19.51,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC39(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.45,
		380: 19.45,
	}

	table777 = {
		0: 16.68,
		200: 9.63,
		300: 16.68,
	}

	table787 = {
		0: 16.68,
		8: 9.63,
		9: 14.2,
		10: 16.68,
	}

	table330 = {
		0: 14.17,
		200: 9.63,
		800: 9.63,
		300: 14.17,
		900: 14.17,
	}

	table340 = {
		0: 14.17,
		200: 14.17,
		300: 14.17,
		500: 19.45,
		600: 19.45,
	}

	table350 = {
		0: 16.68,
		900: 16.68,
		1000: 19.45,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC40(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 19.49,
		380: 19.49,
	}

	table777 = {
		0: 16.62,
		200: 9.62,
		300: 16.62,
	}

	table787 = {
		0: 16.62,
		8: 9.62,
		9: 14.21,
		10: 16.62,
	}

	table330 = {
		0: 14.21,
		200: 9.62,
		800: 9.62,
		300: 14.21,
		900: 14.21,
	}

	table340 = {
		0: 14.21,
		200: 14.21,
		300: 14.21,
		500: 19.49,
		600: 19.49,
	}

	table350 = {
		0: 16.62,
		900: 16.62,
		1000: 19.49,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC42(aircraftData):

	table = {
		0: 0,
		310: 2.22,
		747: 19.97,
		380: 19.97,
	}

	table777 = {
		0: 16.63,
		200: 9.67,
		300: 16.63,
	}

	table787 = {
		0: 16.63,
		8: 9.67,
		9: 13.39,
		10: 16.63,
	}

	table330 = {
		0: 13.39,
		200: 9.67,
		800: 9.67,
		300: 13.39,
		900: 13.39,
	}

	table340 = {
		0: 13.39,
		200: 13.39,
		300: 13.39,
		500: 19.97,
		600: 19.97,
	}

	table350 = {
		0: 16.63,
		900: 16.63,
		1000: 19.97,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC43(aircraftData):

	table = {
		0: 0,
		310: 2.15,
		747: 20.02,
		380: 20.02,
	}

	table777 = {
		0: 16.72,
		200: 9.78,
		300: 16.72,
	}

	table787 = {
		0: 16.72,
		8: 9.78,
		9: 13.48,
		10: 16.72,
	}

	table330 = {
		0: 13.48,
		200: 9.78,
		800: 9.78,
		300: 13.48,
		900: 13.48,
	}

	table340 = {
		0: 13.48,
		200: 13.48,
		300: 13.48,
		500: 20.02,
		600: 20.02,
	}

	table350 = {
		0: 16.72,
		900: 16.72,
		1000: 20.02,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC44(aircraftData):

	table = {
		0: 0,
		310: 2.15,
		747: 19.96,
		380: 19.96,
	}

	table777 = {
		0: 16.63,
		200: 9.68,
		300: 16.63,
	}

	table787 = {
		0: 16.63,
		8: 9.68,
		9: 13.38,
		10: 16.63,
	}

	table330 = {
		0: 13.38,
		200: 9.68,
		800: 9.68,
		300: 13.38,
		900: 13.38,
	}

	table340 = {
		0: 13.38,
		200: 13.38,
		300: 13.38,
		500: 19.96,
		600: 19.96,
	}

	table350 = {
		0: 16.63,
		900: 16.63,
		1000: 19.96,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC45(aircraftData):

	table = {
		0: 0,
		310: 2.13,
		747: 19.85,
		380: 19.85,
	}

	table777 = {
		0: 16.56,
		200: 9.61,
		300: 16.56,
	}

	table787 = {
		0: 16.56,
		8: 9.61,
		9: 13.31,
		10: 16.56,
	}

	table330 = {
		0: 13.31,
		200: 9.61,
		800: 9.61,
		300: 13.31,
		900: 13.31,
	}

	table340 = {
		0: 13.31,
		200: 13.31,
		300: 13.31,
		500: 19.85,
		600: 19.85,
	}

	table350 = {
		0: 16.56,
		900: 16.56,
		1000: 19.85,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC46(aircraftData):

	table = {
		0: 0,
		310: 2.11,
		747: 20.01,
		380: 20.01,
	}

	table777 = {
		0: 16.72,
		200: 9.75,
		300: 16.72,
	}

	table787 = {
		0: 16.72,
		8: 9.75,
		9: 13.48,
		10: 16.72,
	}

	table330 = {
		0: 13.48,
		200: 9.75,
		800: 9.75,
		300: 13.48,
		900: 13.48,
	}

	table340 = {
		0: 13.48,
		200: 13.48,
		300: 13.48,
		500: 20.01,
		600: 20.01,
	}

	table350 = {
		0: 16.72,
		900: 16.72,
		1000: 20.01,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC50(aircraftData):

	table = {
		0: 0,
		310: 2.18,
		747: 18.96,
		380: 18.96,
	}

	table777 = {
		0: 16.63,
		200: 9.23,
		300: 16.63,
	}

	table787 = {
		0: 16.63,
		8: 9.23,
		9: 13.69,
		10: 16.63,
	}

	table330 = {
		0: 13.69,
		200: 9.23,
		800: 9.23,
		300: 13.69,
		900: 13.69,
	}

	table340 = {
		0: 13.69,
		200: 13.69,
		300: 13.69,
		500: 18.96,
		600: 18.96,
	}

	table350 = {
		0: 16.63,
		900: 16.63,
		1000: 18.96,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC51LR(aircraftData):

	table = {
		0: 0,
		319: 6.5,
		320: 6.5,
		321: 6.5,
		190: 6.5,
		195: 6.5,
		737: 6.5,
		757: 11.3,
		300: 11.3,
		310: 11.3,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGateC51(aircraftData):

	table = {
		0: 0,
		380: 9.93,
	}

	table777 = {
		0: 11.29,
		200: 4.12,
		300: 11.29,
	}

	table340 = {
		0: 1.39,
		200: 1.39,
		300: 1.39,
		500: 4.12,
		600: 4.12,
	}

	table350 = {
		0: 2.81,
		900: 2.81,
		1000: 11.29,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC52(aircraftData):

	table = {
		0: 0,
		310: 2.11,
		747: 18.11,
		380: 18.11,
	}

	table777 = {
		0: 16.08,
		200: 8.81,
		300: 16.08,
	}

	table787 = {
		0: 16.08,
		8: 8.81,
		9: 10.97,
		10: 16.08,
	}

	table330 = {
		0: 10.97,
		200: 8.81,
		800: 8.81,
		300: 10.97,
		900: 10.97,
	}

	table340 = {
		0: 10.97,
		200: 10.97,
		300: 10.97,
		500: 18.11,
		600: 18.11,
	}

	table350 = {
		0: 16.08,
		900: 16.08,
		1000: 18.11,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC535455LR(aircraftData):

	table = {
		0: 0,
		319: 11.3,
		320: 11.3,
		321: 13.65,
		737: 13.65,
		757: 13.65,
		300: 13.65,
		310: 13.65,
		190: 13.65,
		195: 13.65,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetGateC53(aircraftData):

	table = {
		0: 0,
		380: 7.63,
	}

	table777 = {
		0: 9.97,
		200: 4.22,
		300: 9.97,
	}

	table340 = {
		0: 1.5,
		200: 1.5,
		300: 1.5,
		500: 4.22,
		600: 4.22,
	}

	table350 = {
		0: 2.89,
		900: 2.89,
		1000: 9.97,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC54(aircraftData):

	table = {
		0: 0,
		380: 7.61,
	}

	table777 = {
		0: 9.96,
		200: 4.12,
		300: 9.96,
	}

	table340 = {
		0: 1.42,
		200: 1.42,
		300: 1.42,
		500: 4.12,
		600: 4.12,
	}

	table350 = {
		0: 2.78,
		900: 2.78,
		1000: 9.96,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC55(aircraftData):

	table = {
		0: 0,
		380: 7.57,
	}

	table777 = {
		0: 9.89,
		200: 4.11,
		300: 9.89,
	}

	table340 = {
		0: 1.51,
		200: 1.51,
		300: 1.51,
		500: 4.11,
		600: 4.11,
	}

	table350 = {
		0: 2.81,
		900: 2.81,
		1000: 9.89,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC57(aircraftData):

	table = {
		0: 0,
		767: 2.1,
		380: 10.8,
	}

	table777 = {
		0: 8.48,
		200: 4.11,
		300: 8.48,
	}

	table787 = {
		0: 2.1,
		8: 2.1,
		9: 5.29,
		10: 8.48,
	}

	table330 = {
		0: 2.1,
		200: 2.1,
		800: 2.1,
		300: 5.29,
		900: 5.29,
	}

	table340 = {
		0: 5.29,
		200: 5.29,
		300: 5.29,
		500: 10.8,
		600: 10.8,
	}

	table350 = {
		0: 8.48,
		900: 8.48,
		1000: 9.89,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC59(aircraftData):

	table = {
		0: 0,
		767: 2.09,
		380: 10.8,
	}

	table777 = {
		0: 8.51,
		200: 2.09,
		300: 8.51,
	}

	table787 = {
		0: 2.09,
		8: 2.09,
		9: 5.3,
		10: 8.51,
	}

	table330 = {
		0: 2.09,
		200: 2.09,
		800: 2.09,
		300: 5.3,
		900: 5.3,
	}

	table340 = {
		0: 5.3,
		200: 5.3,
		300: 5.3,
		500: 10.8,
		600: 10.8,
	}

	table350 = {
		0: 8.51,
		900: 8.51,
		1000: 10.8,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC61(aircraftData):

	table = {
		0: 0,
		767: 2.15,
		380: 10.8,
	}

	table777 = {
		0: 8.47,
		200: 2.15,
		300: 8.47,
	}

	table787 = {
		0: 2.15,
		8: 2.15,
		9: 5.33,
		10: 8.47,
	}

	table330 = {
		0: 2.15,
		200: 2.15,
		800: 2.15,
		300: 5.33,
		900: 5.33,
	}

	table340 = {
		0: 5.3,
		200: 5.33,
		300: 5.33,
		500: 10.8,
		600: 10.8,
	}

	table350 = {
		0: 8.47,
		900: 8.47,
		1000: 10.8,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC62(aircraftData):

	table = {
		0: 0,
		767: 2.08,
		380: 10.83,
	}

	table777 = {
		0: 8.51,
		200: 2.08,
		300: 8.51,
	}

	table787 = {
		0: 2.08,
		8: 2.08,
		9: 5.32,
		10: 8.51,
	}

	table330 = {
		0: 2.08,
		200: 2.08,
		800: 2.08,
		300: 5.32,
		900: 5.32,
	}

	table340 = {
		0: 5.3,
		200: 5.32,
		300: 5.32,
		500: 10.83,
		600: 10.83,
	}

	table350 = {
		0: 8.51,
		900: 8.51,
		1000: 10.83,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC63(aircraftData):

	table = {
		0: 0,
		767: 2.03,
		380: 10.85,
	}

	table777 = {
		0: 8.51,
		200: 2.08,
		300: 8.51,
	}

	table787 = {
		0: 2.08,
		8: 2.08,
		9: 5.29,
		10: 8.51,
	}

	table330 = {
		0: 2.08,
		200: 2.08,
		800: 2.08,
		300: 5.29,
		900: 5.29,
	}

	table340 = {
		0: 5.29,
		200: 5.29,
		300: 5.29,
		500: 10.85,
		600: 10.85,
	}

	table350 = {
		0: 8.51,
		900: 8.51,
		1000: 10.85,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateC64(aircraftData):

	table = {
		0: 0,
		767: 2.1,
		380: 10.9,
	}

	table777 = {
		0: 8.20,
		200: 2.1,
		300: 8.52,
	}

	table787 = {
		0: 2.1,
		8: 2.1,
		9: 5.28,
		10: 8.52,
	}

	table330 = {
		0: 2.1,
		200: 2.1,
		800: 2.1,
		300: 5.28,
		900: 5.28,
	}

	table340 = {
		0: 5.28,
		200: 5.28,
		300: 5.28,
		500: 10.9,
		600: 10.9,
	}

	table350 = {
		0: 8.52,
		900: 8.52,
		1000: 10.9,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			787 : (table787, 0),
			330 : (table330, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD1(aircraftData):

	table = {
		0: 0,
		380: 7.68,
	}

	table777 = {
		0: 10,
		200: 4.19,
		300: 10,
	}

	table340 = {
		0: 1.51,
		200: 1.51,
		300: 1.51,
		500: 4.19,
		600: 4.19,
	}

	table350 = {
		0: 2.84,
		900: 2.84,
		1000: 10,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD2(aircraftData):

	table = {
		0: 0,
		380: 7.62,
	}

	table777 = {
		0: 9.84,
		200: 4.16,
		300: 9.84,
	}

	table340 = {
		0: 1.47,
		200: 1.47,
		300: 1.47,
		500: 4.16,
		600: 4.16,
	}

	table350 = {
		0: 2.7,
		900: 2.7,
		1000: 9.84,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD4(aircraftData):

	table = {
		0: 0,
		380: 7.68,
	}

	table777 = {
		0: 10,
		200: 4.23,
		300: 10,
	}

	table340 = {
		0: 1.49,
		200: 1.49,
		300: 1.49,
		500: 4.23,
		600: 4.23,
	}

	table350 = {
		0: 2.83,
		900: 2.83,
		1000: 10,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD6(aircraftData):

	table = {
		0: 0,
		380: 7.56,
	}

	table777 = {
		0: 9.89,
		200: 4.13,
		300: 9.89,
	}

	table340 = {
		0: 1.46,
		200: 1.46,
		300: 1.46,
		500: 4.13,
		600: 4.13,
	}

	table350 = {
		0: 2.72,
		900: 2.72,
		1000: 9.89,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD7(aircraftData):

	table = {
		0: 0,
		380: 7.57,
	}

	table777 = {
		0: 9.85,
		200: 4.11,
		300: 9.85,
	}

	table340 = {
		0: 1.45,
		200: 1.45,
		300: 1.45,
		500: 4.11,
		600: 4.11,
	}

	table350 = {
		0: 2.7,
		900: 2.7,
		1000: 9.85,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD8(aircraftData):

	table = {
		0: 0,
		380: 7.56,
	}

	table777 = {
		0: 9.88,
		200: 4.15,
		300: 9.88,
	}

	table340 = {
		0: 1.41,
		200: 1.41,
		300: 1.41,
		500: 4.15,
		600: 4.15,
	}

	table350 = {
		0: 2.72,
		900: 2.72,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD9(aircraftData):

	table = {
		0: 0,
		380: 7.5,
	}

	table777 = {
		0: 9.78,
		200: 4.15,
		300: 9.78,
	}

	table340 = {
		0: 1.43,
		200: 1.43,
		300: 1.43,
		500: 4.11,
		600: 4.11,
	}

	table350 = {
		0: 2.63,
		900: 2.63,
		1000: 9.78,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateD10(aircraftData):

	table = {
		0: 0,
		380: 7.54,
	}

	table777 = {
		0: 9.88,
		200: 4.15,
		300: 9.88,
	}

	table340 = {
		0: 1.43,
		200: 1.43,
		300: 1.43,
		500: 4.12,
		600: 4.12,
	}

	table350 = {
		0: 2.76,
		900: 2.76,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateApronE(aircraftData):

	table = {
		0: 0,
		28: 0.98,
		727: 3.18,
		200: 5.3,
		700: 5.3,
		900: 5.3,
		82: 5.3,
		83: 5.3,
		88: 5.3,
	}

	table737 = {
		0: 3.18,
		100: 0,
		200: 0,
		300: 0,
		400: 0,
		500: 0,
		600: 0,
		700: 0,
		800: 3.18,
		900: 3.18,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			737 : (table737, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF2(aircraftData):

	table = {
		0: 0,
		787: 6.52,
		380: 13.65,
	}

	table777 = {
		0: 11.33,
		200: 6.52,
		300: 11.33,
	}

	table350 = {
		0: 11.33,
		900: 11.33,
		1000: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF3(aircraftData):

	table = {
		0: 0,
		380: 7.72,
	}

	table777 = {
		0: 10.03,
		200: 4.1,
		300: 10.03,
	}

	table340 = {
		0: 1.4,
		200: 1.4,
		300: 1.4,
		500: 4.1,
		600: 4.1,
	}

	table350 = {
		0: 2.66,
		900: 2.66,
		1000: 10.03,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF4(aircraftData):

	table = {
		0: 0,
		787: 6.53,
		380: 13.7,
	}

	table777 = {
		0: 11.36,
		200: 6.53,
		300: 11.36,
	}

	table350 = {
		0: 11.36,
		900: 11.36,
		1000: 13.7,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF5(aircraftData):

	table = {
		0: 0,
		787: 6.52,
		380: 13.66,
	}

	table777 = {
		0: 11.32,
		200: 6.52,
		300: 11.32,
	}

	table350 = {
		0: 11.32,
		900: 11.32,
		1000: 13.7,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF6(aircraftData):

	table = {
		0: 0,
		380: 7.63,
	}

	table777 = {
		0: 9.94,
		200: 4.19,
		300: 9.94,
	}

	table340 = {
		0: 1.5,
		200: 1.5,
		300: 1.5,
		500: 4.19,
		600: 4.19,
	}

	table350 = {
		0: 2.67,
		900: 2.67,
		1000: 9.94,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF8(aircraftData):

	table = {
		0: 0,
		380: 7.65,
	}

	table777 = {
		0: 9.88,
		200: 4.17,
		300: 9.88,
	}

	table340 = {
		0: 1.48,
		200: 1.48,
		300: 1.48,
		500: 4.17,
		600: 4.17,
	}

	table350 = {
		0: 2.75,
		900: 2.75,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF9(aircraftData):

	table = {
		0: 0,
		380: 7.53,
	}

	table777 = {
		0: 9.86,
		200: 4.13,
		300: 9.86,
	}

	table340 = {
		0: 1.43,
		200: 1.43,
		300: 1.43,
		500: 4.13,
		600: 4.13,
	}

	table350 = {
		0: 2.72,
		900: 2.72,
		1000: 9.86,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF10(aircraftData):

	table = {
		0: 0,
		380: 7.6,
	}

	table777 = {
		0: 9.94,
		200: 4.12,
		300: 9.94,
	}

	table340 = {
		0: 1.45,
		200: 1.45,
		300: 1.45,
		500: 4.12,
		600: 4.12,
	}

	table350 = {
		0: 2.79,
		900: 2.79,
		1000: 9.94,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF12(aircraftData):

	table = {
		0: 0,
		380: 7.53,
	}

	table777 = {
		0: 9.88,
		200: 4.13,
		300: 9.88,
	}

	table340 = {
		0: 1.45,
		200: 1.45,
		300: 1.45,
		500: 4.13,
		600: 4.13,
	}

	table350 = {
		0: 4.13,
		900: 4.13,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF13(aircraftData):

	table = {
		0: 0,
		380: 7.53,
	}

	table777 = {
		0: 9.88,
		200: 4.13,
		300: 9.88,
	}

	table340 = {
		0: 1.44,
		200: 1.44,
		300: 1.44,
		500: 4.13,
		600: 4.13,
	}

	table350 = {
		0: 2.72,
		900: 2.72,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF14(aircraftData):

	table = {
		0: 0,
		787: 6.52,
		380: 13.65,
	}

	table777 = {
		0: 11.32,
		200: 6.52,
		300: 11.32,
	}

	table350 = {
		0: 11.32,
		900: 11.32,
		1000: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF16(aircraftData):

	table = {
		0: 0,
		787: 6.5,
		380: 13.65,
	}

	table777 = {
		0: 11.31,
		200: 6.5,
		300: 11.31,
	}

	table350 = {
		0: 11.31,
		900: 11.31,
		1000: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF17(aircraftData):

	table = {
		0: 0,
		787: 6.52,
		380: 13.66,
	}

	table777 = {
		0: 11.35,
		200: 6.52,
		300: 11.35,
	}

	table350 = {
		0: 11.35,
		900: 11.35,
		1000: 13.66,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF19(aircraftData):

	table = {
		0: 0,
		380: 7.65,
	}

	table777 = {
		0: 9.88,
		200: 4.12,
		300: 9.88,
	}

	table340 = {
		0: 1.47,
		200: 1.47,
		300: 1.47,
		500: 4.12,
		600: 4.12,
	}

	table350 = {
		0: 2.72,
		900: 2.72,
		1000: 9.88,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF20(aircraftData):

	table = {
		0: 0,
		380: 7.63,
	}

	table777 = {
		0: 9.96,
		200: 4.25,
		300: 9.96,
	}

	table340 = {
		0: 1.46,
		200: 1.46,
		300: 1.46,
		500: 4.25,
		600: 4.25,
	}

	table350 = {
		0: 2.81,
		900: 2.81,
		1000: 9.96,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF21(aircraftData):

	table = {
		0: 0,
		380: 7.6,
	}

	table777 = {
		0: 9.92,
		200: 4.18,
		300: 9.92,
	}

	table340 = {
		0: 1.46,
		200: 1.46,
		300: 1.46,
		500: 4.18,
		600: 4.18,
	}

	table350 = {
		0: 2.76,
		900: 2.76,
		1000: 9.92,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF22(aircraftData):

	table = {
		0: 0,
		380: 7.7,
	}

	table777 = {
		0: 10.03,
		200: 4.2,
		300: 10.03,
	}

	table340 = {
		0: 1.51,
		200: 1.51,
		300: 1.51,
		500: 4.2,
		600: 4.2,
	}

	table350 = {
		0: 2.89,
		900: 2.89,
		1000: 10.03,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF23F24(aircraftData):

	table = {
		0: 0,
		787: 6.51,
		380: 13.66,
	}

	table777 = {
		0: 11.33,
		200: 6.51,
		300: 11.33,
	}

	table350 = {
		0: 11.33,
		900: 11.33,
		1000: 13.66,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF26(aircraftData):

	table = {
		0: 0,
		380: 7.62,
	}

	table777 = {
		0: 9.91,
		200: 4.22,
		300: 9.91,
	}

	table340 = {
		0: 1.55,
		200: 1.55,
		300: 1.55,
		500: 4.22,
		600: 4.22,
	}

	table350 = {
		0: 2.82,
		900: 2.82,
		1000: 9.91,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			340 : (table340, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetGateF27(aircraftData):

	table = {
		0: 0,
		787: 6.52,
		380: 13.68,
	}

	table777 = {
		0: 11.35,
		200: 6.52,
		300: 11.35,
	}

	table350 = {
		0: 11.35,
		900: 11.35,
		1000: 13.68,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetApronG(aircraftData):

	table = {
		0: 0,
		787: 6.5,
		747: 11.33,
		380: 13.65,
	}

	table777 = {
		0: 11.33,
		200: 6.5,
		300: 11.33,
	}

	table350 = {
		0: 11.3,
		900: 11.3,
		1000: 13.65,
	}

	global HandleAircraftOffsets
	return Distance.fromMeters(HandleAircraftOffsets( aircraftData, 
		{ 
			777 : (table777, 0),
			350 : (table350, 0),
		},
		table) )

@AlternativeStopPositions
def customOffsetApronSandGateH3(aircraftData):

	table = {
		0: 0,
		777: 6.5,
		787: 6.5,
		319: 11.33,
		320: 11.33,
		170: 11.33,
		175: 11.33,
		190: 11.33,
		195: 11.33,
		321: 13.65,
		737: 13.65,
		757: 13.65,
		300: 13.65,
		310: 13.65,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

def MyStandNames(name, letter, priority):
	return CustomizedName( "%s|Stand %s#§" % (name, letter), priority )

ApronANames = MyStandNames("Apron A", "A", 1)
ApronBNames = MyStandNames("Apron B", "B", 2)
ApronCNames = MyStandNames("Apron C", "C", 3)
ApronDNames = MyStandNames("Apron D", "D", 4)
ApronENames = MyStandNames("Apron E", "E", 5)
ApronFNames = MyStandNames("Apron F", "F", 6)
ApronGNames = MyStandNames("Apron G", "G", 7)
ApronHNames = MyStandNames("Apron H", "H", 8)
ApronQNames = MyStandNames("Apron Q", "Q", 9)
ApronSNames = MyStandNames("Apron S", "S", 10)
OtherNames = MyStandNames("Others", "", 10)

parkings = {
	GATE_A : {
		None : ( ),
				2 : (ApronANames, customOffsetGateA2),
				3 : (ApronANames, customOffsetGateA3),
				4 : (ApronANames, customOffsetGateA4),
				5 : (ApronANames, customOffsetGateA5),
				6 : (ApronANames, customOffsetGateA6),
				8 : (ApronANames, customOffsetGateA8),
				9 : (ApronANames, customOffsetGateA9),
				10 : (ApronANames, customOffsetGateA10),
	},
	GATE_B : {
		None : ( ),
				1 : (ApronBNames, customOffsetGateB1),
				2 : (ApronBNames, customOffsetGateB2B3B4B6),
				3 : (ApronBNames, customOffsetGateB2B3B4B6),
				4 : (ApronBNames, customOffsetGateB2B3B4B6),
				6 : (ApronBNames, customOffsetGateB2B3B4B6),
				8 : (ApronBNames, customOffsetGateB8B9B10),
				9 : (ApronBNames, customOffsetGateB8B9B10),
				10 : (ApronBNames, customOffsetGateB8B9B10),
				11 : (ApronBNames, customOffsetGateB11),
				14 : (ApronBNames, customOffsetGateB14),
				15 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				16 : (ApronBNames, customOffsetGateB16),
				18 : (ApronBNames, customOffsetStands1line),
				20 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				21 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				22 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				23 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				24 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				25 : (ApronBNames, customOffsetGateB15B20B21B22B23B24B25),
				26 : (ApronBNames, customOffsetStands1line),
				27 : (ApronBNames, customOffsetGateB27),
	},
	GATE_C : {
		None : ( ),
				18 : (ApronCNames, customOffsetGateC18C19C20C21C22C23),
				19 : (ApronCNames, customOffsetGateC18C19C20C21C22C23),
				20 : (ApronCNames, customOffsetGateC18C19C20C21C22C23),
				21 : (ApronCNames, customOffsetGateC18C19C20C21C22C23),
				22 : (ApronCNames, customOffsetGateC18C19C20C21C22C23),
				23 : (ApronCNames, customOffsetGateC18C19C20C21C22C23),
				24 : (ApronCNames, customOffsetGateC24C25C26C27),
				25 : (ApronCNames, customOffsetGateC24C25C26C27),
				26 : (ApronCNames, customOffsetGateC24C25C26C27),
				27 : (ApronCNames, customOffsetGateC24C25C26C27),
				28 : (ApronCNames, customOffsetGateC28),
				29 : (ApronCNames, customOffsetGateC29),
				30 : (ApronCNames, customOffsetGateC30),
				31 : (ApronCNames, customOffsetGateC31),
				32 : (ApronCNames, customOffsetGateC32),
				34 : (ApronCNames, customOffsetGateC34),
				35 : (ApronCNames, customOffsetGateC35),
				36 : (ApronCNames, customOffsetGateC36),
				37 : (ApronCNames, customOffsetGateC37),
				38 : (ApronCNames, customOffsetGateC38),
				39 : (ApronCNames, customOffsetGateC39),
				40 : (ApronCNames, customOffsetGateC40),
				42 : (ApronCNames, customOffsetGateC42),
				43 : (ApronCNames, customOffsetGateC43),
				44 : (ApronCNames, customOffsetGateC44),
				45 : (ApronCNames, customOffsetGateC45),
				46 : (ApronCNames, customOffsetGateC46),
				50 : (ApronCNames, customOffsetGateC50),
				"51L" : (ApronCNames, customOffsetGateC51LR),
				51 : (ApronCNames, customOffsetGateC51),
				"51R" : (ApronCNames, customOffsetGateC51LR),
				52 : (ApronCNames, customOffsetGateC52),
				"53L" : (ApronCNames, customOffsetGateC535455LR),
				53 : (ApronCNames, customOffsetGateC53),
				"53R" : (ApronCNames, customOffsetGateC535455LR),
				"54L" : (ApronCNames, customOffsetGateC535455LR),
				54 : (ApronCNames, customOffsetGateC54),
				"54R" : (ApronCNames, customOffsetGateC535455LR),
				"55L" : (ApronCNames, customOffsetGateC535455LR),
				55 : (ApronCNames, customOffsetGateC55),
				"55R" : (ApronCNames, customOffsetGateC535455LR),
				57 : (ApronCNames, customOffsetGateC57),
				59 : (ApronCNames, customOffsetGateC59),
				61 : (ApronCNames, customOffsetGateC61),
				62 : (ApronCNames, customOffsetGateC62),
				63 : (ApronCNames, customOffsetGateC63),
				64 : (ApronCNames, customOffsetGateC64),
	},
	GATE_D : {
		None : ( ),
				1 : (ApronDNames, customOffsetGateD1),
				2 : (ApronDNames, customOffsetGateD2),
				4 : (ApronDNames, customOffsetGateD4),
				6 : (ApronDNames, customOffsetGateD6),
				7 : (ApronDNames, customOffsetGateD7),
				8 : (ApronDNames, customOffsetGateD8),
				9 : (ApronDNames, customOffsetGateD9),
				10 : (ApronDNames, customOffsetGateD10),
	},
	GATE_E : {
		None : ( ),
				1 : (ApronENames, customOffsetGateApronE),
				2 : (ApronENames, customOffsetGateApronE),
				3 : (ApronENames, customOffsetGateApronE),
				4 : (ApronENames, customOffsetGateApronE),
				5 : (ApronENames, customOffsetGateApronE),
				6 : (ApronENames, customOffsetGateApronE),
				7 : (ApronENames, customOffsetGateApronE),
				8 : (ApronENames, customOffsetGateApronE),
				9 : (ApronENames, customOffsetGateApronE),
				10 : (ApronENames, customOffsetGateApronE),
				11 : (ApronENames, customOffsetGateApronE),
				12 : (ApronENames, customOffsetGateApronE),
				13 : (ApronENames, customOffsetGateApronE),
				14 : (ApronENames, customOffsetGateApronE),
				15 : (ApronENames, customOffsetGateApronE),
				16 : (ApronENames, customOffsetGateApronE),
				17 : (ApronENames, customOffsetGateApronE),
				18 : (ApronENames, customOffsetGateApronE),
				19 : (ApronENames, customOffsetGateApronE),
				20 : (ApronENames, customOffsetGateApronE),
				21 : (ApronENames, customOffsetGateApronE),
				22 : (ApronENames, customOffsetGateApronE),
				23 : (ApronENames, customOffsetGateApronE),
				24 : (ApronENames, customOffsetGateApronE),
				25 : (ApronENames, customOffsetGateApronE),
				26 : (ApronENames, customOffsetGateApronE),
				27 : (ApronENames, customOffsetGateApronE),
				28 : (ApronENames, customOffsetGateApronE),
				29 : (ApronENames, customOffsetGateApronE),
				30 : (ApronENames, customOffsetGateApronE),
				31 : (ApronENames, customOffsetGateApronE),
				32 : (ApronENames, customOffsetGateApronE),
				33 : (ApronENames, customOffsetGateApronE),
				45 : (ApronENames, customOffsetGateApronE),
				36 : (ApronENames, customOffsetGateApronE),
				37 : (ApronENames, customOffsetGateApronE),
				38 : (ApronENames, customOffsetGateApronE),
				43 : (ApronENames, customOffsetStands1line),
				44 : (ApronENames,customOffsetGateApronE ),
				"44L" : (ApronENames, customOffsetGateApronE),
				"44R" : (ApronENames, customOffsetGateApronE),
				45 : (ApronENames, customOffsetStands1line),
				"45L" : (ApronENames, customOffsetStands1line),
				"45R" : (ApronENames, customOffsetStands1line),
	},
	GATE_F : {
		None : ( ),
				2 : (ApronFNames, customOffsetGateF2),
				3 : (ApronFNames, customOffsetGateF3),
				4 : (ApronFNames, customOffsetGateF4),
				5 : (ApronFNames, customOffsetGateF5),
				6 : (ApronFNames, customOffsetGateF6),
				8 : (ApronFNames, customOffsetGateF8),
				9 : (ApronFNames, customOffsetGateF9),
				10 : (ApronFNames, customOffsetGateF10),
				12 : (ApronFNames, customOffsetGateF12),
				13 : (ApronFNames, customOffsetGateF13),
				14 : (ApronFNames, customOffsetGateF14),
				16 : (ApronFNames, customOffsetGateF16),
				17 : (ApronFNames, customOffsetGateF17),
				19 : (ApronFNames, customOffsetGateF19),
				20 : (ApronFNames, customOffsetGateF20),
				21 : (ApronFNames, customOffsetGateF21),
				22 : (ApronFNames, customOffsetGateF22),
				23 : (ApronFNames, customOffsetGateF23F24),
				24 : (ApronFNames, customOffsetGateF23F24),
				26 : (ApronFNames, customOffsetGateF26),
				27 : (ApronFNames, customOffsetGateF27),
	},
	GATE_G : {
		None : ( ),
				1 : (ApronGNames, customOffsetApronG),
				2 : (ApronGNames, customOffsetApronG),
				3 : (ApronGNames, customOffsetApronG),
				4 : (ApronGNames, customOffsetApronG),
				5 : (ApronGNames, customOffsetApronG),
				6 : (ApronGNames, customOffsetApronG),
				7 : (ApronGNames, customOffsetApronG),
				8 : (ApronGNames, customOffsetApronG),
				9 : (ApronGNames, customOffsetApronG),
				10 : (ApronGNames, customOffsetApronG),
				11 : (ApronGNames, customOffsetApronG),
				12 : (ApronGNames, customOffsetApronG),
				13 : (ApronGNames, customOffsetApronG),
				14 : (ApronGNames, customOffsetApronG),
				15 : (ApronGNames, customOffsetApronG),
				16 : (ApronGNames, customOffsetApronG),
				17 : (ApronGNames, customOffsetApronG),
				18 : (ApronGNames, customOffsetApronG),
				19 : (ApronGNames, customOffsetApronG),
				20 : (ApronGNames, customOffsetApronG),
				21 : (ApronGNames, customOffsetApronG),
				22 : (ApronGNames, customOffsetApronG),
	},
	GATE_H : {
		None : ( ),
				1 : (ApronHNames, customOffsetStands1line),
				2 : (ApronHNames, customOffsetStands1line),
				3 : (ApronHNames, customOffsetApronSandGateH3),
				4 : (ApronHNames, customOffsetStands1line),
	},
	GATE_Q : {
		None : ( ),
				1 : (ApronQNames, customOffsetStands1line),
				2 : (ApronQNames, customOffsetStands1line),
				3 : (ApronQNames, customOffsetStands1line),
				4 : (ApronQNames, customOffsetStands1line),
				5 : (ApronQNames, customOffsetStands1line),
				6 : (ApronQNames, customOffsetStands1line),
				7 : (ApronQNames, customOffsetStands1line),
				8 : (ApronQNames, customOffsetStands1line),
				9 : (ApronQNames, customOffsetStands1line),
				10 : (ApronQNames, customOffsetStands1line),
				11 : (ApronQNames, customOffsetStands1line),
	},
	GATE_S : {
		None : ( ),
				1 : (ApronSNames, customOffsetApronSandGateH3),
				2 : (ApronSNames, customOffsetApronSandGateH3),
				3 : (ApronSNames, customOffsetApronSandGateH3),
				4 : (ApronSNames, customOffsetApronSandGateH3),
				5 : (ApronSNames, customOffsetApronSandGateH3),
				6 : (ApronSNames, customOffsetApronSandGateH3),
				7 : (ApronSNames, customOffsetApronSandGateH3),
				8 : (ApronSNames, customOffsetApronSandGateH3),
				9 : (ApronSNames, customOffsetApronSandGateH3),
				10 : (ApronSNames, customOffsetApronSandGateH3),
				11 : (ApronSNames, customOffsetApronSandGateH3),
				12 : (ApronSNames, customOffsetApronSandGateH3),
				13 : (ApronSNames, customOffsetApronSandGateH3),
				14 : (ApronSNames, customOffsetApronSandGateH3),
				15 : (ApronSNames, customOffsetApronSandGateH3),
	},
	PARKING : {
		None : ( ),
				1 : (OtherNames, customOffsetStands1line),
				31 : (ApronENames, ApronENames),
				32 : (ApronENames, ApronENames),
				34 : (ApronENames, ApronENames),
				35 : (ApronENames, ApronENames),
				37 : (ApronENames, ApronENames),
				38 : (ApronENames, ApronENames),
				42 : (OtherNames, customOffsetStands1line),
				43 : (OtherNames, customOffsetStands1line),
				44 : (OtherNames, customOffsetStands1line),
				45 : (OtherNames, customOffsetStands1line),
				46 : (OtherNames, customOffsetStands1line),
				60 : (OtherNames, customOffsetStands1line),
				61 : (OtherNames, customOffsetStands1line),
				62 : (OtherNames, customOffsetStands1line),
				63 : (OtherNames, customOffsetStands1line),
				64 : (OtherNames, customOffsetStands1line),
				65 : (OtherNames, customOffsetStands1line),
				211 : (OtherNames, customOffsetStands1line),
	},
}