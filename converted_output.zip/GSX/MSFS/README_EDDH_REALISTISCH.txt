GSX Pro – MSFS 2024 – EDDH (Sim‑Wings) – Realistisch Preset
Erstellt: 2026-02-11

Was wurde geändert (nur EDDH-Profil, NICHT global):
- Alle Parkpositionen mit "hasjetway = 1" werden auf:
  - parkingsystem = VDGS
  - nopassengerstairs = 1
  - nopassengerbus = 1
  - nopassengerbus_deboarding = 1
  => Ergebnis: Jetway-Gates haben VDGS + Pax über Jetway, keine Busse/Treppen.
- Alle anderen Stands bleiben wie in deiner Datei (Marshaller/Bus/Stairs je nach Stand).

Installation:
1) MSFS beenden.
2) Win+R -> %APPDATA%\Virtuali\GSX\MSFS
3) Datei "eddh-qqm5stfe.ini" aus diesem ZIP in den Ordner kopieren (Überschreiben erlauben).
4) MSFS starten -> EDDH laden -> GSX Menü -> "Restart Couatl" (falls nötig).

Wichtig (Sim‑Wings VDGS / doppelte Displays):
- Wenn du an Gates doppelte VDGS siehst (Szenerie + GSX), dann:
  a) Entweder die statischen VDGS der Szenerie entfernen (falls Sim‑Wings Option/Tool/Config bietet),
  b) oder dieses Preset NICHT verwenden und an den Gates wieder "Marshaller" wählen.
  (Viele Sim‑Wings EDDH GSX-Profile empfehlen, statische VDGS zu entfernen, weil sie die GSX-VDGS überlagern.) 

Backup:
- Original liegt im ZIP als "eddh-qqm5stfe_ORIGINAL_BACKUP.ini".
