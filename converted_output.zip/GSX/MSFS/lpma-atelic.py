# -- coding: utf-8 --

msfs_mode = 1
icao = "lpma"

@AlternativeStopPositions
def customOffsetStands1line(aircraftData):

	table = {
		0: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetStandard(aircraftData):

	table = {
		0: 0,
		28: 0,
		318: 0.98,
		319: 0.98,
		320: 0.98,
		321: 0.98,
		736: 2.04,
		737: 2.04,
		738: 2.04,
		739: 2.04,
		100: 2.04,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetMain(aircraftData):

	table = {
		0: 0,
		28: 0,
		318: 0.90,
		319: 0.90,
		320: 0.90,
		321: 6.30,
		736: 1.80,
		737: 1.80,
		738: 1.80,
		739: 1.80,
		757: 5.30,
		321: 6.30,
		82: 9.0,
		83: 9.0,
		88: 9.0,

	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetMain2(aircraftData):

	table = {
		0: 0,
		318: 0,
		319: 0,
		320: 0,
		321: 5.40,
		736: 0.90,
		737: 0.90,
		738: 0.90,
		739: 0.90,
		757: 4.30,
		321: 6.30,
		82: 8.10,
		83: 8.10,
		88: 8.10,

	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

@AlternativeStopPositions
def customOffsetMain3(aircraftData):

	table = {
		0: 0,
		28: 0,
		318: 0.87,
		319: 0.87,
		320: 0.87,
		321: 0.87,
		736: 1.71,
		737: 1.71,
		738: 1.71,
		739: 1.71,
		757: 4.45,
		321: 4.45,
		82: 4.45,
		83: 4.45,
		88: 4.45,
		330: 11.90,

	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) )

def MyStandNames(name, letter, priority):
	return CustomizedName( "%s|Stand %s#§" % (name, letter), priority )

MainApronNames = MyStandNames("Main Apron", "A", 1)

parkings = {
	GATE_A : {
		None : (MainApronNames, customOffsetStandard),
		1 : (MainApronNames, customOffsetStandard),
		2 : (MainApronNames, customOffsetStandard),
		3 : (MainApronNames, customOffsetStandard),
		4 : (MainApronNames, customOffsetStandard),
		5 : (MainApronNames, customOffsetStandard),
		6 : (MainApronNames, customOffsetStandard),
		7 : (MainApronNames, customOffsetMain),
		8 : (MainApronNames, customOffsetMain),
		9 : (MainApronNames, customOffsetMain),
		10 : (MainApronNames, customOffsetMain2),
		11 : (MainApronNames, customOffsetMain2),
		12 : (MainApronNames, customOffsetMain2),
		13 : (MainApronNames, customOffsetMain3),
		14 : (MainApronNames, customOffsetStands1line),
		15 : (MainApronNames, customOffsetStands1line),
		16 : (MainApronNames, customOffsetStands1line),
		17 : (MainApronNames, customOffsetStands1line),
		18 : (MainApronNames, customOffsetStands1line),
		19 : (MainApronNames, customOffsetStands1line),
	},
}