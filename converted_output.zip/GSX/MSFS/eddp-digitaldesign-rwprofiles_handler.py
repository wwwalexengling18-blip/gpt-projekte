msfs_mode = 1

# ============================================================
# EDIT THIS PER AIRPORT
# ============================================================

AIRPORT_ICAO = "EDDP"
SCENERY_TITLE = "Digital Design EDDP Leipzig"

# Handling operator selection (SimBrief ICAO airline -> GSX operator code)
_AIRLINE_TO_HANDLER = {
	"BCS": "DHL",
	"BOX": "DHL",
	"DHK": "DHL",
	"DHX": "DHL",
}

# Default handling operator for any airline NOT listed above
_DEFAULT_HANDLER = "LEIPZIG"

# If no airline ICAO can be detected at all, allow GSX to pick from these
_FALLBACK_HANDLERS = "LEIPZIG,DHL"

# Catering operator selection (SimBrief ICAO airline -> GSX catering operator)
_CATERING_BY_AIRLINE = {
}

# If no match is found, allow GSX to pick from these (comma-separated list is valid)
_CATERING_FALLBACK = "GGOURMET"


# Vehicle preferences (per-airport)
# Add more blocks per vehicleType if you needed (e.g. "Pushback", "BaggageLoader", etc.)
AIRPORT_VEHICLE_PREFERENCES = {
	"BaggageTractor": [
		{
			"prefer_title_contains": ["Endurance"],
			"prefer_texture_contains": [],
			"boost": 25,
		},
	],
}

# Texture preferences (per-operator)
HANDLER_VEHICLE_PREFERENCES = {
}

_GATE_DISTANCE_THRESHOLD_METERS = 25


# ============================================================
# SHARED CODE (DON'T TOUCH)
# ============================================================

_PKEY_MODE = "rwprofiles_handling_mode"
_cached_mode = None


def _is_this_airport():
	a = getAirport()
	return bool(a and getattr(a, "icao", None) == AIRPORT_ICAO)


def _get_icao_airline_from_simbrief():
	sb = getSimbrief()
	if not sb:
		return None
	if getattr(sb, "last_error", None):
		return None
	code = getattr(sb, "icao_airline", None)
	if not code:
		return None
	return str(code).strip().upper()


def _ensure_user_mode_choice():
	global _cached_mode

	if _cached_mode in ("auto", "manual"):
		return

	mode = getGlobalPersistentVariable(_PKEY_MODE, None)
	if mode in ("auto", "manual"):
		_cached_mode = mode
		return

	result = choiceBox(
		"WELCOME TO %s!\n\n"
		"NEW FEATURE:\n"
		"This profile can automatically select the ground handling and catering\n"
		"company based on your airline.\n\n"
		"WHICH METHOD WOULD YOU LIKE TO USE?\n\n"
		"AUTOMATIC (SIMBRIEF):\n"
		"- Reads your SimBrief airline ICAO code\n"
		"- Auto-selects the correct company at this airport\n"
		"- If there’s no match, GSX will show the operator list\n\n"
		"MANUAL (OPERATOR LIST):\n"
		"- GSX always shows the operator list\n"
		"- You choose the company each time\n\n"
		"Your choice is remembered for future visits to all RW GSX Profiles\n"
		"with this feature." % SCENERY_TITLE,
		"%s - GSX Profile" % SCENERY_TITLE,
		["AUTOMATIC (RECOMMENDED)", "MANUAL"],
		default=0,
	)

	if result is None:
		_cached_mode = "auto"
		return

	_cached_mode = "auto" if result == 0 else "manual"
	setGlobalPersistentVariable(_PKEY_MODE, _cached_mode)


def _resolve_airline_icao():
	icao = _get_icao_airline_from_simbrief()
	if not icao:
		icao = getattr(aircraft, "icaoAirline", None)
		if icao:
			icao = str(icao).strip().upper()
	return icao


def _resolve_handler_for_airline(icao):
	if icao and icao in _AIRLINE_TO_HANDLER:
		return _AIRLINE_TO_HANDLER[icao]
	if icao and _DEFAULT_HANDLER:
		return _DEFAULT_HANDLER
	return _FALLBACK_HANDLERS


def _pick_textures():
	_ensure_user_mode_choice()

	# Manual mode: always show lists (if your fallbacks are lists)
	if _cached_mode == "manual":
		return _FALLBACK_HANDLERS, _CATERING_FALLBACK, None

	icao = _resolve_airline_icao()
	handling_texture = _resolve_handler_for_airline(icao)

	if icao and icao in _CATERING_BY_AIRLINE:
		catering_texture = _CATERING_BY_AIRLINE[icao]
	else:
		catering_texture = _CATERING_FALLBACK

	return handling_texture, catering_texture, icao


def _apply_operators():
	gate = getGate()
	if not gate:
		return

	handling_texture, catering_texture, icao = _pick_textures()
	gate.handlingTexture = handling_texture
	gate.cateringTexture = catering_texture

	print("%s: mode=%s airline=%s handling=%s catering=%s" % (
		AIRPORT_ICAO,
		_cached_mode,
		icao or "None",
		handling_texture,
		catering_texture
	))


def _apply_gate_distance_threshold():
	if _GATE_DISTANCE_THRESHOLD_METERS is None:
		return

	gate = getGate()
	if not gate:
		return

	try:
		d = Distance.fromMeters(_GATE_DISTANCE_THRESHOLD_METERS)
	except Exception:
		return

	try:
		gate.__setattr__("gateDistanceThreshold", d)
	except Exception:
		pass


def onEnterAirport(self):
	if not _is_this_airport():
		return
	_apply_operators()
	_apply_gate_distance_threshold()
	_show_agnis_lateral_guidance_message()


def onAirportBeforeVehicleSelect(self):
	if not _is_this_airport():
		return
	_apply_operators()
	_apply_gate_distance_threshold()
	_apply_terminal1_bus_override()
	_show_agnis_lateral_guidance_message()


def _normalize_pref_list(pref_block):
	if not pref_block:
		return []

	if isinstance(pref_block, list):
		return pref_block

	if isinstance(pref_block, dict):
		return [pref_block]

	return []


def _collect_preferences(vehicleType, icao, handler_code):
	prefs = []

	try:
		prefs.extend(_normalize_pref_list(
			AIRPORT_VEHICLE_PREFERENCES.get(vehicleType, None)
		))
	except Exception:
		pass

	try:
		handler_block = HANDLER_VEHICLE_PREFERENCES.get(handler_code, None) if handler_code else None
		if handler_block:
			prefs.extend(_normalize_pref_list(
				handler_block.get(vehicleType, None)
			))
	except Exception:
		pass

	try:
		airline_block = AIRLINE_VEHICLE_PREFERENCES.get(icao, None) if icao else None
		if airline_block:
			prefs.extend(_normalize_pref_list(
				airline_block.get(vehicleType, None)
			))
	except Exception:
		pass

	return prefs

def onAirportVehicleCandidatesScored(self, vehicleType, candidates):
	if not _is_this_airport():
		return

	icao = _resolve_airline_icao()
	if icao:
		icao = str(icao).strip().upper()

	handler_code = _resolve_handler_for_airline(icao)

	prefs = _collect_preferences(vehicleType, icao, handler_code)
	if not prefs:
		return

	for c in candidates:
		try:
			title = str(getattr(c, "title", "") or "")
		except Exception:
			title = ""

		try:
			texture = str(getattr(c, "texture", "") or "")
		except Exception:
			texture = ""

		for pref in prefs:
			title_needles = pref.get("prefer_title_contains", [])
			texture_needles = pref.get("prefer_texture_contains", [])
			boost = pref.get("boost", 0)

			if not boost or (not title_needles and not texture_needles):
				continue

			matched = False

			for needle in title_needles:
				if needle and needle in title:
					matched = True
					break

			if not matched:
				for needle in texture_needles:
					if needle and needle in texture:
						matched = True
						break

			if matched:
				c.boostScore(boost)
