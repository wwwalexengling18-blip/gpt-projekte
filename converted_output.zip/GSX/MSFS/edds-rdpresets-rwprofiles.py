# -- coding: utf-8 --

msfs_mode = 1
icao = "edds"

def HandleAircraftOffsets(specificTables, genericTable):
	try:
		return specificTables[aircraftData.idMajor][0].get(aircraftData.idMinor)
	except:
		try:
			return specificTables[aircraftData.idMajor][0].get(specificTables[aircraftData.idMajor][1])
		except:
			return genericTable.get(aircraftData.idMajor, 0)

@AlternativeStopPositions
def customOffsetRemotes40to48(aircraftData):
	table = {
		0: 0,
		170: 0,
		175: 0,
		190: 0,
		195: 0,
		221: 0,
		223: 0,
		318: 0,
		319: 0,
		320: 0,
		321: 0,
		737: 0,
		757: 0,
		700: 0,
		900: 0,
		1000: 0,
	}

	return Distance.fromMeters( table.get(aircraftData.idMajor, 0) - 0.25 )

def TerminalNames(name, letter, priority):
	return CustomizedName( "%s|Gate %s#§" % (letter , name), priority )

def RemoteNames(name, letter, priority):
	return CustomizedName( "%s|Stand %s#§" % (letter, name), priority )

Terminal = TerminalNames("", "Terminal", 1)
Remotes = RemoteNames("", "Remotes", 2)
Cargo = RemoteNames("", "Cargo", 3)
GeneralAviation = RemoteNames("", "General Aviation", 4)

parkings = {
	GATE : {
		None : ( ),
		9 : (Terminal, ),
		10 : (Terminal, ),
		11 : (Terminal, ),
		12 : (Terminal, ),
		13 : (Terminal, ),
		14 : (Terminal, ),
		15 : (Terminal, ),
		16 : (Terminal, ),
		17 : (Remotes, ),
		18 : (Remotes, ),
		19 : (Remotes, ),
		24 : (Remotes, ),
		25 : (Remotes, ),
		26 : (Remotes, ),
		27 : (Remotes, ),
		28 : (Remotes, ),
		29 : (Remotes, ),
		30 : (Remotes, ),
		31 : (Remotes, ),
		32 : (Remotes, ),
		33 : (Remotes, ),
		34 : (Remotes, ),
		35 : (Remotes, ),
		36 : (Remotes, ),
	},
	PARKING : {
		None : ( ),
		1 : (GeneralAviation, ),
		2 : (GeneralAviation, ),
		4 : (GeneralAviation, ),
		5 : (GeneralAviation, ),
		6 : (GeneralAviation, ),
		9 : (GeneralAviation, ),
		10 : (GeneralAviation, ),
		11 : (GeneralAviation, ),
		12 : (GeneralAviation, ),
		13 : (GeneralAviation, ),
		15 : (GeneralAviation, ),
		16 : (GeneralAviation, ),
		18 : (GeneralAviation, ),
		19 : (GeneralAviation, ),
		20 : (GeneralAviation, ),
		22 : (GeneralAviation, ),
		23 : (GeneralAviation, ),
		24 : (GeneralAviation, ),
		43 : (Remotes, customOffsetRemotes40to48),
		51 : (Remotes, ),
		53 : (Remotes, ),
		55 : (Remotes, ),
		56 : (Remotes, ),
		62 : (Remotes, ),
		100 : (Cargo, ),
		101 : (Cargo, ),
		102 : (Cargo, ),
		103 : (Cargo, ),
		104 : (Cargo, ),
		106 : (Cargo, ),
		200 : (Cargo, ),
		201 : (Cargo, ),
		202 : (Cargo, ),
		203 : (Cargo, ),
		204 : (Cargo, ),
	},
	0 : {
		None : ( ),
		40 : (Remotes, customOffsetRemotes40to48),
		41 : (Remotes, customOffsetRemotes40to48),
		42 : (Remotes, customOffsetRemotes40to48),
		45 : (Remotes, customOffsetRemotes40to48),
		46 : (Remotes, customOffsetRemotes40to48),
		47 : (Remotes, customOffsetRemotes40to48),
		48 : (Remotes, customOffsetRemotes40to48),
		50 : (Remotes, ),
		52 : (Remotes, ),
		54 : (Remotes, ),
		60 : (Remotes, ),
		61 : (Remotes, ),
		63 : (Remotes, ),
		64 : (Remotes, ),
		71 : (Remotes, ),
		72 : (Remotes, ),
		73 : (Remotes, ),
		74 : (Remotes, ),
		75 : (Remotes, ),
	},
}